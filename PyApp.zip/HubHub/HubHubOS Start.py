import subprocess
import sys

rute = 'Code/Code/HubHubOS.py'

subprocess.Popen([sys.executable, rute])