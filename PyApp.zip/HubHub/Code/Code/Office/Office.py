from tkinter import Tk, Label, PhotoImage, Button, colorchooser, messagebox
import tkinter as tk
import subprocess
import sys

#####################Start Of The code
########################Variables

color = 'black'

#########################End Of Variables And Start Of Images

ventana1 = tk.Tk()
ventana1.title("HubHubOS Office")
ventana1.geometry('1600x780')
ventana1.config(bg='light grey')

#################################More

BWork0 = tk.Button(ventana1, bd=0, highlightthickness=0, relief='flat', anchor='w', font=('Arial', 25), text="Send Gmail", fg=color, bg='light grey', width=30, height=1)
BWork0.place(x=250, y=500)

BWork01 = tk.Button(ventana1, bd=0, highlightthickness=0, relief='flat', anchor='w', font=('Arial', 25), text="Send Chat", fg=color, bg='light grey', width=30, height=1)
BWork01.place(x=250, y=570)

BWork02 = tk.Button(ventana1, bd=0, highlightthickness=0, relief='flat', anchor='w', font=('Arial', 25), text="Start Meeting", fg=color, bg='light grey', width=30, height=1)
BWork02.place(x=250, y=640)

####################################################Defs

def Codec():
    rute = 'Code/Code/Office/Codec.py'
    subprocess.Popen([sys.executable, rute])

def Contabilc():
    rute = 'Code/Code/Office/Financic.py'
    subprocess.Popen([sys.executable, rute])

#####################################End Of Defs And Start Of Images

image1 = PhotoImage(file="Images/Menus/Office.png")

##########################End Of Images

Office1 = tk.Frame(ventana1, borderwidth=0, width=220, height=780, bg='royalblue', bd=0, highlightthickness=0, relief='flat')
Office1.pack_propagate(False)
Office1.place(x=0, y=0)

####################################################

Office2 = tk.Frame(ventana1, borderwidth=0, width=240, height=300, bg='silver', bd=0, highlightthickness=0, relief='flat')
Office2.pack_propagate(False)
Office2.place(x=300, y=80)

Work1 = tk.Label(ventana1, font=('Arial', 25), text="Documento En Blanco", fg=color, bg='light grey', width=18, height=1, bd=0, highlightthickness=0, relief='flat')
Work1.place(x=250, y=400)

boton00 = tk.Button(ventana1, bg='#DDEEF9', bd=0, highlightthickness=0, relief='flat')
boton00.place(x=325, y=105, width=190, height=250) 

C1 = tk.Button(ventana1, font=('Arial', 45, 'bold'), bg='#AABBF9', fg='whitesmoke', text="W", bd=0,highlightthickness=0, relief='flat')
C1.place(x=325, y=205, width=110, height=150) 

##########################################

Office3 = tk.Frame(ventana1, borderwidth=0, width=240, height=300, bg='silver', bd=0, highlightthickness=0, relief='flat')
Office3.pack_propagate(False)
Office3.place(x=700, y=80)

Work2 = tk.Label(ventana1, font=('Arial', 25), text="Calendario En Blanco", fg=color, bg='light grey', width=18, height=1, bd=0, highlightthickness=0, relief='flat')
Work2.place(x=640, y=400)

boton01 = tk.Button(ventana1, bg='#FFEEDD', bd=0, highlightthickness=0, relief='flat')
boton01.place(x=725, y=105, width=90, height=250) 

B1 = tk.Button(ventana1, bg='#FFEEDD', bd=0, highlightthickness=0, relief='flat')
B1.place(x=825, y=105, width=90, height=90) 

B2 = tk.Button(ventana1, bg='#FFEEDD', bd=0, highlightthickness=0, relief='flat')
B2.place(x=825, y=205, width=90, height=90) 

B3 = tk.Button(ventana1, bg='#FFEEDD', bd=0, highlightthickness=0, relief='flat')
B3.place(x=825, y=305, width=90, height=50) 

C2 = tk.Button(ventana1, font=('Arial', 45, 'bold'), bg='#FFCC22', fg='whitesmoke', text="C", bd=0,highlightthickness=0, relief='flat')
C2.place(x=725, y=205, width=110, height=150) 

####################################################

Office4 = tk.Frame(ventana1, borderwidth=0, bd=0, highlightthickness=0, relief='flat', width=240, height=300, bg='silver')
Office4.pack_propagate(False)
Office4.place(x=1100, y=80)

Work3 = tk.Label(ventana1, font=('Arial', 25), bd=0, highlightthickness=0, relief='flat', text="Empezar Finanza", fg=color, bg='light grey', width=18, height=1)
Work3.place(x=1040, y=400)

boton02 = tk.Button(ventana1, bg='#DDFFDD', bd=0, highlightthickness=0, relief='flat', command=Contabilc)
boton02.place(x=1125, y=105, width=110, height=250) 

B4 = tk.Button(ventana1, bg='#DDFFDD', bd=0, highlightthickness=0, relief='flat', command=Contabilc)
B4.place(x=1245, y=105, width=70, height=50) 

B5 = tk.Button(ventana1, bg='#DDFFDD', bd=0, highlightthickness=0, relief='flat', command=Contabilc)
B5.place(x=1245, y=165, width=70, height=70) 

B6 = tk.Button(ventana1, bg='#DDFFDD', bd=0, highlightthickness=0, relief='flat', command=Contabilc)
B6.place(x=1245, y=245, width=70, height=50) 

B7 = tk.Button(ventana1, bg='#DDFFDD', bd=0, highlightthickness=0, relief='flat', command=Contabilc)
B7.place(x=1245, y=305, width=70, height=50) 

C3 = tk.Button(ventana1, font=('Arial', 45, 'bold'), bg='#64FF24', fg='whitesmoke', text="F", bd=0,highlightthickness=0, relief='flat', command=Contabilc)
C3.place(x=1125, y=205, width=110, height=150) 

#####################################################Buttons

boton0 = tk.Button(ventana1, font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="⁝⁝⁝", bd=0, highlightthickness=0, relief='flat', width=3, height=1)
boton0.place(x=10, y=10) 

boton1 = tk.Button(ventana1, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Word", bd=0, highlightthickness=0, relief='flat', width=8, height=1)
boton1.place(x=15, y=100) 

boton2 = tk.Button(ventana1, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calendar", bd=0, highlightthickness=0, relief='flat', width=8, height=1)
boton2.place(x=15, y=180) 

boton3 = tk.Button(ventana1, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Financic", bd=0, highlightthickness=0, relief='flat', width=8, height=1, command=Contabilc)
boton3.place(x=15, y=260) 

boton4 = tk.Button(ventana1, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calc", bd=0, highlightthickness=0, relief='flat', width=8, height=1)
boton4.place(x=15, y=340) 

boton5 = tk.Button(ventana1, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Planific", bd=0, highlightthickness=0, relief='flat', width=8, height=1)
boton5.place(x=15, y=420) 

boton6 = tk.Button(ventana1, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Codec", bd=0, highlightthickness=0, relief='flat', width=8, height=1, command=Codec)
boton6.place(x=15, y=500) 

boton7 = tk.Button(ventana1, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="…", bd=0, highlightthickness=0, relief='flat', width=8, height=1)
boton7.place(x=20, y=580) 

boton8 = tk.Button(ventana1, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Help       ?", bd=0, highlightthickness=0, relief='flat', width=8, height=1)
boton8.place(x=15, y=700) 

ventana1.mainloop()