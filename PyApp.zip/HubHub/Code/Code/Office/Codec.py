import tkinter as tk
from tkinter import scrolledtext
import sys
from io import StringIO
import os
import threading
from tkinter import filedialog, colorchooser, font, messagebox

#########################################################################33

# Crear la ventana principal
ventana = tk.Tk()
ventana.title("HubHubOS Visual Code")
ventana.geometry('1800x780')
ventana.config(bg='#444444')

net = 70

inner1_frame = tk.Frame(ventana, borderwidth=0, width=1700, heigh=net, bg='#3C3C3C')
inner1_frame.pack_propagate(False)  # Evita que el frame se ajuste al tamaño del contenido
inner1_frame.place(x=100, y=0)

place = 100
next_place = 1537 - place
our_place = place - 10

# Crear un área de texto con barras de desplazamiento
text_area = scrolledtext.ScrolledText(ventana)
text_area.config(bg='#333333', fg='#EEEEEE',  font = ('calibri', 20, 'bold'), bd=0, highlightthickness=0, relief='flat')
text_area.place(x=place, y=70, width=next_place, height=500)

# Crear un área de texto con barras de desplazamiento
text_area1 = scrolledtext.ScrolledText(ventana)
text_area1.config(bg='#333333', fg='#EEEEEE',  font = ('calibri', 20, 'bold'), bd=0, highlightthickness=0, relief='flat')
text_area1.place(x=place, y=595, width=next_place, height=175)

#################################################################################3333 

keywords_with_colors = {
    'lightblue': ['import', 'from', 'as'],
    'royalblue': ['True', 'False', '=', '"', "'", '(', ')', 'ScrolledText', 'show', 'Button', 'Label', 'Frame', '.', ':'],
    'green': ['def', 'return', 'class', '#'],
    'pink': ['pass', 'if', 'elif', 'else:'],
    'lightyellow': ['print'],
    'red':['if', 'else', 'try', 'except'],
    # Puedes agregar más colores y palabras clave según sea necesario
}

# Función para resaltar palabras clave con colores específicos
def highlight_keywords_with_colors(event=None):
    for color, keywords in keywords_with_colors.items():
        for keyword in keywords:
            start_index = '1.0'
            while True:
                start_index = text_area.search(keyword, start_index, tk.END)
                if not start_index:
                    break
                end_index = f"{start_index}+{len(keyword)}c"
                text_area.tag_add(keyword, start_index, end_index)
                text_area.tag_config(keyword, foreground=color)
                start_index = end_index
    text_area.edit_modified(False)  # reset the modified flag

text_area.bind('<KeyRelease>', highlight_keywords_with_colors)

# Función para capturar la salida estándar

class StdRedirector:
    def __init__(self, text_widget):
        self.text_widget = text_widget
        self.buffer = ""

    def readline(self):
        self.buffer = ""
        while True:
            self.text_widget.update()  # Update the wi dget to receive input
            if self.buffer.endswith('\n'):  # Wait for the user to press Enter
                break
        user_input = self.buffer[:-1]  # Remove the newline character
        self.buffer = ""
        return user_input

    def write(self, string):
        self.text_widget.insert(tk.END, string)
        self.text_widget.see(tk.END)

    def flush(self):
        pass  # No-op for now

    def input(self, prompt=""):
        self.write(prompt)
        return self.readline()

def execute_code():
  
    code = text_area.get("1.0", tk.END)
    old_stdout = sys.stdout
    sys.stdout = redirector  # Redirige stdout al widget text_area1
    try:
        exec(code, {'__name__': '__main__'})
    except Exception as e:
        print(f"Error ejecutando el código: {e}")
    sys.stdout = old_stdout
    old_stdin = sys.stdin
    sys.stdout = redirector
    sys.stdin = redirector
    try:
        exec(code)
    except Exception as e:
        print(f"Error executing code: {e}")
    sys.stdout = old_stdout
    sys.stdin = old_stdin

redirector = StdRedirector(text_area1)
sys.stdin = redirector
sys.stdout = redirector

def read_input():
    while True:
        user_input = redirector.readline()
        redirector.write(">>> " + user_input + "\n")  # Echo the input
        sys.stdin.write(user_input + "\n")  # Write the input to sys.stdin

input_thread = threading.Thread(target=read_input)
input_thread.daemon = True  # Set as daemon thread
input_thread.start()

#####################################################################33

# Crear un botón para ejecutar el código
play = tk.Button(ventana, bg='#3C3C3C', fg='whitesmoke', font = ('calibri', 25, 'bold'),text="▶", bd=0, highlightthickness=0, relief='flat', command=execute_code)
play.place(x=1470, y=5)

def save():
    file = filedialog.asksaveasfilename(initialfile="untitled.py", defaultextension=".py")
    if file is None:
        return
    else:
        try:
            file = open(file, "w")
            file.write(text_area.get(1.0, tk.END))
        except Exception:
            messagebox.showerror("HubHubOs Error", "No se pudo guardar el archivo correctamente")


b1 = tk.Button(ventana, bg='#444444', fg='whitesmoke', font = ('calibri', 25, 'bold'),text="Save", bd=0, highlightthickness=0, relief='flat', command=save)
b1.place(x=2, y=25, width=our_place, height=75)

def clean():
    text_area.delete(1.0, tk.END)

b2 = tk.Button(ventana, bg='#444444', fg='whitesmoke', font = ('calibri', 25, 'bold'),text="Clean", bd=0, highlightthickness=0, relief='flat', command=clean)
b2.place(x=2, y=100, width=our_place, height=75)

# Iniciar el bucle principal de Tkinter

ventana.mainloop()
