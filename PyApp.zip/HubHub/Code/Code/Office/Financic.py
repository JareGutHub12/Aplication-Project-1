import tkinter as tk
from tkinter import PhotoImage, Label
import time

tiempo = .001

size = 8

ventana1 = tk.Tk()
ventana1.title('HubHubOS Financic')
ventana1.geometry('1600x780')
ventana1.config(bg='light grey')

ventana2 = tk.Toplevel()
ventana2.title('HubHubOS Financic')
ventana2.geometry('1600x780')
ventana2.config(bg='light grey')
ventana2.withdraw()

ventana3 = tk.Toplevel()
ventana3.title('HubHubOS Financic')
ventana3.geometry('1600x780')
ventana3.config(bg='light grey')
ventana3.withdraw()

ventana4= tk.Toplevel()
ventana4.title('HubHubOS Financic')
ventana4.geometry('1600x780')
ventana4.config(bg='light grey')
ventana4.withdraw()

ventana5 = tk.Toplevel()
ventana5.title('HubHubOS Financic')
ventana5.geometry('1600x780')
ventana5.config(bg='light grey')
ventana5.withdraw()

ventana6 = tk.Toplevel()
ventana6.title('HubHubOS Financic')
ventana6.geometry('1600x780')
ventana6.config(bg='light grey')
ventana6.withdraw()

ventana7= tk.Toplevel()
ventana7.title('HubHubOS Financic')
ventana7.geometry('1600x780')
ventana7.config(bg='light grey')
ventana7.withdraw()

ventana8 = tk.Toplevel()
ventana8.title('HubHubOS Financic')
ventana8.geometry('1600x780')
ventana8.config(bg='light grey')
ventana8.withdraw()

Office1 = tk.Frame(ventana1,borderwidth=0, width=220, height=780, bg='royalblue')
Office1.pack_propagate(False)
Office1.place(x=0, y=0)

Office2 = tk.Frame(ventana2,borderwidth=0, width=220, height=780, bg='royalblue')
Office2.pack_propagate(False)
Office2.place(x=0, y=0)

Office3 = tk.Frame(ventana3,borderwidth=0, width=220, height=780, bg='royalblue')
Office3.pack_propagate(False)
Office3.place(x=0, y=0)

Office4 = tk.Frame(ventana4,borderwidth=0, width=220, height=780, bg='royalblue')
Office4.pack_propagate(False)
Office4.place(x=0, y=0)

Office5 = tk.Frame(ventana5,borderwidth=0, width=220, height=780, bg='royalblue')
Office5.pack_propagate(False)
Office5.place(x=0, y=0)

Office6 = tk.Frame(ventana6,borderwidth=0, width=220, height=780, bg='royalblue')
Office6.pack_propagate(False)
Office6.place(x=0, y=0)

Office7 = tk.Frame(ventana7,borderwidth=0, width=220, height=780, bg='royalblue')
Office7.pack_propagate(False)
Office7.place(x=0, y=0)

Office8 = tk.Frame(ventana8,borderwidth=0, width=220, height=780, bg='royalblue')
Office8.pack_propagate(False)
Office8.place(x=0, y=0)

#######################################################333

I1 = PhotoImage(file="Code/Code/Office/Images/I1.png")

F1 = tk.Frame(ventana7, borderwidth=0, width=1000, height=600)
F1.pack_propagate(False)
F1.place(x=235, y=50)

L1 = Label(F1, image=I1)
L1.photo = I1
L1.pack()

#############################################ToFrames, UP

def dir1():
    ventana1.withdraw()
    ventana2.withdraw()
    ventana3.withdraw()
    ventana4.withdraw()
    ventana5.withdraw()
    ventana6.withdraw()
    ventana7.withdraw()
    ventana8.withdraw()
    time.sleep(tiempo)
    ventana1.deiconify()

def dir2():
    ventana1.withdraw()
    ventana2.withdraw()
    ventana3.withdraw()
    ventana4.withdraw()
    ventana5.withdraw()
    ventana6.withdraw()
    ventana7.withdraw()
    ventana8.withdraw()
    time.sleep(tiempo)
    ventana2.deiconify()

def dir3():
    ventana1.withdraw()
    ventana2.withdraw()
    ventana3.withdraw()
    ventana4.withdraw()
    ventana5.withdraw()
    ventana6.withdraw()
    ventana7.withdraw()
    ventana8.withdraw()
    time.sleep(tiempo)
    ventana3.deiconify()

def dir4():
    ventana1.withdraw()
    ventana2.withdraw()
    ventana3.withdraw()
    ventana4.withdraw()
    ventana5.withdraw()
    ventana6.withdraw()
    ventana7.withdraw()
    ventana8.withdraw()
    time.sleep(tiempo)
    ventana4.deiconify()

def dir5():
    ventana1.withdraw()
    ventana2.withdraw()
    ventana3.withdraw()
    ventana4.withdraw()
    ventana5.withdraw()
    ventana6.withdraw()
    ventana7.withdraw()
    ventana8.withdraw()
    time.sleep(tiempo)
    ventana5.deiconify()

def dir6():
    ventana1.withdraw()
    ventana2.withdraw()
    ventana3.withdraw()
    ventana4.withdraw()
    ventana5.withdraw()
    ventana6.withdraw()
    ventana7.withdraw()
    ventana8.withdraw()
    time.sleep(tiempo)
    ventana6.deiconify()

def dir7():
    ventana1.withdraw()
    ventana2.withdraw()
    ventana3.withdraw()
    ventana4.withdraw()
    ventana5.withdraw()
    ventana6.withdraw()
    ventana7.withdraw()
    ventana8.withdraw()
    time.sleep(tiempo)
    ventana7.deiconify()

def dir8():
    ventana1.withdraw()
    ventana2.withdraw()
    ventana3.withdraw()
    ventana4.withdraw()
    ventana5.withdraw()
    ventana6.withdraw()
    ventana7.withdraw()
    ventana8.withdraw()
    time.sleep(tiempo)
    ventana8.deiconify()

def dir9():
    pass

w = ventana1

boton0 = tk.Button(w, anchor='w', font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Home", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir1)
boton0.place(x=15, y=10) 

boton1 = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calculator", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir2)
boton1.place(x=15, y=100) 

boton2 = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn I", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir3)#Financic
boton2.place(x=15, y=180) 

boton3 = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn II", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir4)#Contabilc
boton3.place(x=15, y=260) 

boton4 = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Taxes", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir5)
boton4.place(x=15, y=340) 

boton5 = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Inflation", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir6)
boton5.place(x=15, y=420) 

boton6 = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Actions", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir7)
boton6.place(x=15, y=500) 

boton7 = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Money", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir8)
boton7.place(x=20, y=580) 

boton8 = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Help       ?", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir9)
boton8.place(x=15, y=700) 

w = ventana2

boton0A = tk.Button(w, anchor='w', font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Home", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir1)
boton0A.place(x=15, y=10) 

boton1A = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calculator", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir2)
boton1A.place(x=15, y=100) 

boton2A = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn I", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir3)#Financic
boton2A.place(x=15, y=180) 

boton3A = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn II", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir4)#Contabilc
boton3A.place(x=15, y=260) 

boton4A = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Taxes", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir5)
boton4A.place(x=15, y=340) 

boton5A = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Inflation", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir6)
boton5A.place(x=15, y=420) 

boton6A = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Actions", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir7)
boton6A.place(x=15, y=500) 

boton7A = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Money", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir8)
boton7A.place(x=20, y=580) 

boton8A = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Help       ?", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir9)
boton8A.place(x=15, y=700) 

w = ventana3

boton0B = tk.Button(w, anchor='w', font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Home", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir1)
boton0B.place(x=15, y=10) 

boton1B = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calculator", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir2)
boton1B.place(x=15, y=100) 

boton2B = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn I", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir3)#Financic
boton2B.place(x=15, y=180) 

boton3B = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn II", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir4)#Contabilc
boton3B.place(x=15, y=260) 

boton4B = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Taxes", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir5)
boton4B.place(x=15, y=340) 

boton5B = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Inflation", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir6)
boton5B.place(x=15, y=420) 

boton6B = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Actions", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir7)
boton6B.place(x=15, y=500) 

boton7B = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Money", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir8)
boton7B.place(x=20, y=580) 

boton8B = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Help       ?", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir9)
boton8B.place(x=15, y=700) 

w = ventana4

boton0C = tk.Button(w, anchor='w', font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Home", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir1)
boton0C.place(x=15, y=10) 

boton1C = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calculator", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir2)
boton1C.place(x=15, y=100) 

boton2C = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn I", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir3)#Financic
boton2C.place(x=15, y=180) 

boton3C = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn II", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir4)#Contabilc
boton3C.place(x=15, y=260) 

boton4C = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Taxes", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir5)
boton4C.place(x=15, y=340) 

boton5C = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Inflation", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir6)
boton5C.place(x=15, y=420) 

boton6C = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Actions", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir7)
boton6C.place(x=15, y=500) 

boton7C = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Money", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir8)
boton7C.place(x=20, y=580) 

boton8C = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Help       ?", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir9)
boton8C.place(x=15, y=700) 

w = ventana5

boton0D = tk.Button(w, anchor='w', font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Home", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir1)
boton0D.place(x=15, y=10) 

boton1D = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calculator", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir2)
boton1D.place(x=15, y=100) 

boton2D = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn I", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir3)#Financic
boton2D.place(x=15, y=180) 

boton3D = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn II", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir4)#Contabilc
boton3D.place(x=15, y=260) 

boton4D = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Taxes", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir5)
boton4D.place(x=15, y=340) 

boton5D = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Inflation", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir6)
boton5D.place(x=15, y=420) 

boton6D = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Actions", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir7)
boton6D.place(x=15, y=500) 

boton7D = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Money", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir8)
boton7D.place(x=20, y=580) 

boton8D = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Help       ?", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir9)
boton8D.place(x=15, y=700) 

w = ventana6

boton0E = tk.Button(w, anchor='w', font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Home", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir1)
boton0E.place(x=15, y=10) 

boton1E = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calculator", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir2)
boton1E.place(x=15, y=100) 

boton2E = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn I", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir3)#Financic
boton2E.place(x=15, y=180) 

boton3E = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn II", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir4)#Contabilc
boton3E.place(x=15, y=260) 

boton4E = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Taxes", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir5)
boton4E.place(x=15, y=340) 

boton5E = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Inflation", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir6)
boton5E.place(x=15, y=420) 

boton6E = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Actions", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir7)
boton6E.place(x=15, y=500) 

boton7E = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Money", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir8)
boton7E.place(x=20, y=580) 

boton8E = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Help       ?", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir9)
boton8E.place(x=15, y=700) 

w = ventana7

boton0F = tk.Button(w, anchor='w', font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Home", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir1)
boton0F.place(x=15, y=10) 

boton1F = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calculator", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir2)
boton1F.place(x=15, y=100) 

boton2F = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn I", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir3)#Financic
boton2F.place(x=15, y=180) 

boton3F = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn II", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir4)#Contabilc
boton3F.place(x=15, y=260) 

boton4F = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Taxes", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir5)
boton4F.place(x=15, y=340) 

boton5F = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Inflation", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir6)
boton5F.place(x=15, y=420) 

boton6F = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Actions", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir7)
boton6F.place(x=15, y=500) 

boton7F = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Money", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir8)
boton7F.place(x=20, y=580) 

boton8F = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Help       ?", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir9)
boton8F.place(x=15, y=700) 

w = ventana8

boton0G = tk.Button(w, anchor='w', font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Home", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir1)
boton0G.place(x=15, y=10) 

boton1G = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Calculator", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir2)
boton1G.place(x=15, y=100) 

boton2G = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn I", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir3)#Financic
boton2G.place(x=15, y=180) 

boton3G = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Learn II", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir4)#Contabilc
boton3G.place(x=15, y=260) 

boton4G = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Taxes", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir5)
boton4G.place(x=15, y=340) 

boton5G = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Inflation", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir6)
boton5G.place(x=15, y=420) 

boton6G = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Actions", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir7)
boton6G.place(x=15, y=500) 

boton7G = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Money", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir8)
boton7G.place(x=20, y=580) 

boton8G = tk.Button(w, anchor='w' ,font=('Arial', 30), bg='#4169E9', fg='whitesmoke', text="Help       ?", bd=0, highlightthickness=0, relief='flat', width=size, height=1, command=dir9)
boton8G.place(x=15, y=700) 

############################################################333

ventana1.mainloop()