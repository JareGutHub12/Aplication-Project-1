from tkinter import Tk, Label, PhotoImage, Button, colorchooser, messagebox
from datetime import datetime
from time import strftime
import tkinter as tk
import subprocess
import webbrowser
import time
import sys
import re
import os

###########################################################

#Variables extra importantes

necesary = 10000000000000000000

reloj = 0.001

versión = "0.165.000"

web = 'https://jaredamm1.wixsite.com/commx'

color1 = 'light grey'

##########################################################

#def update_progress_bar(canvas, rectangle, window, percent=0):
#    canvas.coords(rectangle, 0, 200, percent * 9, 300)  # Cambia el tamaño del rectángulo
#    window.update()  # Actualiza la ventana para mostrar el cambio
#    if percent < 100:  # Si no hemos llegado al 100%, actualizamos de nuevo después de un tiempo
#        window.after(50, update_progress_bar, canvas, rectangle, window, percent+2)

#window = tk.Toplevel()
#canvas = tk.Canvas(window, width=1600, height=780)
#canvas.pack()


# Crea un rectángulo (inicialmente de tamaño 0) y añade la imagen
#rectangle = canvas.create_rectangle(0, 200, 900, 300, fill="blue")
#update_progress_bar(canvas, rectangle, window)

########################################3333333

def on_entry_click(event):
    if cuadro_texto.get() == 'Escribe aquí un username':
        cuadro_texto.delete(0, "end") # elimina el texto predeterminado
        cuadro_texto.config(fg='black')

def on_focusout(event):
    if cuadro_texto.get() == '':
        cuadro_texto.insert(0, 'Escribe aquí un username') # reinserta el texto predeterminado
        cuadro_texto.config(fg='grey')

def on_entry1_click(event):
    if cuadro1_texto.get() == 'Escribe aquí la contraseña':
        cuadro1_texto.delete(0, "end") # elimina el texto predeterminado
        cuadro1_texto.config(fg='black')

def on_focusout1(event):
    if cuadro1_texto.get() == '':
        cuadro1_texto.insert(0, 'Escribe aquí la contraseña') # reinserta el texto predeterminado
        cuadro1_texto.config(fg='grey')

def on_entry2_click(event):
    if cuadro2_texto.get() == 'Escribe aquí la URL, nota si es URL que tenga HTTPS://':
        cuadro2_texto.delete(0, "end") # elimina el texto predeterminado
        cuadro2_texto.config(fg='black')

def on_focusout2(event):
    if cuadro2_texto.get() == '':
        cuadro2_texto.insert(0, 'Escribe aquí la URL, nota si es URL que tenga HTTPS://') # reinserta el texto predeterminado
        cuadro2_texto.config(fg='grey')

size = '1600x780'

ventanaIS = tk.Tk()
ventanaIS.geometry(size)
ventanaIS.title('Iniciar Seción, HubHubOS')
ventanaIS.config(bg=color1)

ventanaHH = tk.Toplevel()
ventanaHH.geometry(size)
ventanaHH.title('HubHubOS')
ventanaHH.config(bg=color1)
ventanaHH.withdraw()

ventana2 = tk.Toplevel()
ventana2.geometry(size)
ventana2.title('HubHubOS Browser')
ventana2.config(bg=color1)
ventana2.withdraw()

ventana3 = tk.Toplevel()
ventana3.geometry(size)
ventana3.title('HubHubOS Uninstall')
ventana3.config(bg="royalblue")
ventana3.withdraw()

##########################################################

ventanaC1 = tk.Toplevel()
ventanaC1.geometry(size)
ventanaC1.title('HubHubOS')
ventanaC1.config(bg='light grey')
ventanaC1.withdraw()

ventanaC2 = tk.Toplevel()
ventanaC2.geometry(size)
ventanaC2.title('HubHubOS')
ventanaC2.config(bg='light grey')
ventanaC2.withdraw()

ventanaC3 = tk.Toplevel()
ventanaC3.geometry(size)
ventanaC3.title('HubHubOS')
ventanaC3.config(bg='light grey')
ventanaC3.withdraw()

ventanaC4 = tk.Toplevel()
ventanaC4.geometry(size)
ventanaC4.title('HubHubOS')
ventanaC4.config(bg='light grey')
ventanaC4.withdraw()

ventanaC5 = tk.Toplevel()
ventanaC5.geometry(size)
ventanaC5.title('HubHubOS')
ventanaC5.config(bg='whitesmoke')
ventanaC5.withdraw()

ventanaC6 = tk.Toplevel()
ventanaC6.geometry(size)
ventanaC6.title('HubHubOS')
ventanaC6.config(bg='light grey')
ventanaC6.withdraw()

ventanaC7 = tk.Toplevel()
ventanaC7.geometry(size)
ventanaC7.title('HubHubOS')
ventanaC7.config(bg='light grey')
ventanaC7.withdraw()

ventanaC8 = tk.Toplevel()
ventanaC8.geometry(size)
ventanaC8.title('HubHubOS')
ventanaC8.config(bg='light grey')
ventanaC8.withdraw()

ventanaP = tk.Toplevel()
ventanaP.geometry(size)
ventanaP.title('HubHubOS Pets')
ventanaP.config(bg='light grey')
ventanaP.withdraw()

######################################PantallazoAzul

ventanaPA = tk.Toplevel()
ventanaPA.geometry('1600x780')
ventanaPA.title('HubHubOS Error')
ventanaPA.config(bg='royalblue')
ventanaPA.withdraw()

ventanaPA2 = tk.Toplevel()
ventanaPA2.geometry('1600x780')
ventanaPA2.title('Solucionador de HubHubOS')
ventanaPA2.config(bg='royalblue')
ventanaPA2.withdraw()

Blue = tk.Frame(ventanaPA, borderwidth=0, width=1500, height=600, bg='royalblue')
Blue.pack_propagate(False)
Blue.place(x=50, y=50)

labelblue1 = Label(Blue, font=("Arial", 50),text="Error en el Sistema",bg='royalblue', fg='whitesmoke')
labelblue1.place(x=50, y=50)

labelblue1 = Label(Blue, font=("Arial", 25),text="Al parecer HubHubOS tuvo un error, pudo ser de memoria, CPU o piratería",bg='royalblue', fg='whitesmoke')
labelblue1.place(x=50, y=150)

def Try():
    ventanaPA.withdraw()
    ventanaPA2.deiconify()

###############BotonesPantallazoAzul

botonPA = tk.Button(ventanaPA, font=('Arial', 20), bg='#4270E1', fg='whitesmoke', text="Intentar", bd=0, highlightthickness=0, relief='flat', width=18, height=1,command=Try)
botonPA.place(x=50, y=660) 

def Seguir():
    ventanaPA2.withdraw()
    ventanaIS.deiconify()

botonPA = tk.Button(ventanaPA2, font=('Arial', 20), bg='#4270E1', fg='whitesmoke', text="Seguir", bd=0, highlightthickness=0, relief='flat', width=18, height=1,command=Seguir)
botonPA.place(x=50, y=100) 

def Actualizar():
    ventanaPA2.withdraw()
    ventanaC8.deiconify()

botonPA = tk.Button(ventanaPA2, font=('Arial', 20), bg='#4270E1', fg='whitesmoke', text="Actualizar", bd=0, highlightthickness=0, relief='flat', width=18, height=1,command=Actualizar)
botonPA.place(x=50, y=200) 

def MS():
    ventanaPA2.withdraw()
    ventanaIS.deiconify()
    MD()

botonPA = tk.Button(ventanaPA2, font=('Arial', 20), bg='#4270E1', fg='whitesmoke', text="Modo Seguro", bd=0, highlightthickness=0, relief='flat', width=20, height=1,command=MS)
botonPA.place(x=50, y=300) 


def SD():
    messagebox.showwarning("HubHubOS", "¿Seguro de apagar el equipo?")
    subprocess.run(["shutdown", "/s", "/t", "0"])

botonPA = tk.Button(ventanaPA2, font=('Arial', 20), bg='#4270E1', fg='whitesmoke', text="ShutDown", bd=0, highlightthickness=0, relief='flat', width=20, height=1,command=SD)
botonPA.place(x=50, y=400) 

def SDA():
    Delete()

botonPA = tk.Button(ventanaPA2, font=('Arial', 20), bg='#4270E1', fg='whitesmoke', text="Desinstalar", bd=0, highlightthickness=0, relief='flat', width=20, height=1,command=SDA)
botonPA.place(x=50, y=500) 

##########################################################

def Browser1():
    texto2 = cuadro2_texto.get()
    
    # Verifica si la entrada parece una URL usando una expresión regular simple
    if re.match(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', texto2):
        # Si la entrada parece una URL, ábrela directamente
        webbrowser.open(texto2)
        RD()
    else:
        # Si no, realiza una búsqueda en Google
        busqueda = "+".join(texto2.split())
        webbrowser.open(f"https://www.google.com/search?q={busqueda}")
        RD()

def Gam():
    webbrowser.open(f"https://poki.com/en")
    webbrowser.open(f"https://steampowered.com/en")
    RD()

##########################################################################

photo = PhotoImage(file="Images/Menus/Menu.png")  # Carga la imagen desde el mismo directorio que tu script

# Crea un frame llamado inner1ABC_frame
inner1_frame = tk.Frame(ventanaIS, borderwidth=0, width=800, height=780)
inner1_frame.pack_propagate(False)  # Evita que el frame se ajuste al tamaño del contenido
inner1_frame.place(x=0, y=0)

# Añade la imagen al frame
label = Label(inner1_frame, image=photo, bg='royalblue')
label.photo = photo  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
label.pack()

##########################################################################

# Definir las variables de posición

PAP = 670

photobar = PhotoImage(file="Images/Menus/Bar.png")

inner1B_frame = tk.Frame(ventanaHH, borderwidth=0, width=1600, height=100)
inner1B_frame.pack_propagate(False)
inner1B_frame.place(x=0, y=PAP)

labelbar = Label(inner1B_frame, image=photobar, bg=color1)
labelbar.photo = photobar
labelbar.pack()

####################################################################################

innerABC_frame = tk.Frame(ventanaHH, borderwidth=0, width=1600, height=100, bg='red')
innerABC_frame.pack_propagate(False)  # Evita que el marco se ajuste al tamaño del contenido
innerABC_frame.place(x=0, y=400)  # Usar las variables cb y db para la posición
innerABC_frame.pack()  # Mostrar el frame inicialmente
innerABC_frame.pack_forget()  # Ocultar el frame al inicio

###########################################################################

###########################################################################Menu

innerABC_frame = tk.Frame(ventanaHH, borderwidth=0, width=920, height=550, bg='whitesmoke')
innerABC_frame.pack_propagate(False)  # Evita que el marco se ajuste al tamaño del contenido
innerABC_frame.place(x=10, y=115)  # Usar las variables cb y db para la posición

innerABC_frame.place_forget()  # Ocultar el frame al inicio

###########################################################################

def HH():
    if innerABC_frame.winfo_ismapped():  # Verifica si el frame está visible
        time.sleep(reloj)
        innerABC_frame.place_forget()  # Oculta el frame
        innerABCa_frame.place_forget()  # Oculta el frame
        inner1am_frame.place_forget()
        botonpaiH1.place_forget()
        botonpi.place_forget()
        botonpip.place_forget()
        botonpaint.place_forget()
        botonpet.place_forget()
        botonbn.place_forget()
        RD()
        
    else:
        innerABC_frame.place(x=10, y=115)  # Muestra el frame
        innerABCa_frame.place(x=200, y=255)  # Muestra el frame
        inner1am_frame.place(x=25, y=150)  # Muestra el frame
        botonpaiH1.place(x=250, y=200) 
        botonpi.place(x=380, y=200) 
        botonpip.place(x=510, y=200)
        botonpaint.place(x=640, y=200)
        botonpet.place(x=770, y=200)
        botonbn.place(x=250, y=350)
        RD()

def H():
    HH()
    RD()
    
def Calc():
    ruta_script = "Code/Code/Calculadora.py"
    subprocess.Popen(["python", ruta_script])
    RD()

def HCalc():
    H()
    Calc()
    RD()

def HN():
    H()
    Browser()
    RD()

def HC():
    H()
    C()
    RD()

def HP():
    H()
    P()
    RD()

def HB():
    H()
    B()
    RD()

def P():
    ruta_script = 'Code/Code/Paint.py'
    subprocess.Popen(["python", ruta_script])
    RD()

def B():
    ruta_script = 'Code/Code/BlocNotas.py'
    subprocess.Popen([sys.executable, ruta_script])
    RD()

def C():
    ventanaC1.deiconify()
    time.sleep(reloj)
    ventanaHH.withdraw()
    RD()

##########################################################################

innerABCa_frame = tk.Frame(ventanaHH, borderwidth=0, width=10, height=400)
innerABCa_frame.pack_propagate(False)  # Evita que el marco se ajuste al tamaño del contenido
innerABCa_frame.place(x=200, y=255)  # Usar las variables cb y db para la posición
innerABCa_frame.place_forget()  # Ocultar el frame al inicio

photo356 = PhotoImage(file="Images/Navegator/Navegator.png")  # Carga la imagen desde el mismo directorio que tu script

# Crea un frame llamado inner1ABC_frame con un fondo blanco
inner1ABCn_frame = tk.Frame(ventana2, width=280, height=280, bg=color1)
inner1ABCn_frame.pack_propagate(False)  # Evita que el frame se ajuste al tamaño del contenido
inner1ABCn_frame.pack()

# Añade la imagen al frame
label123n = Label(inner1ABCn_frame, image=photo356, bg=color1)
label123n.photo = photo356  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
label123n.pack()

##########################################################################

photoab = PhotoImage(file="Images/Icons/Future/User1.png")  # Carga la imagen desde el mismo directorio que tu script

# Crea un frame llamado inner1ABC_frame
inner1am_frame = tk.Frame(ventanaHH, borderwidth=0, width=130, height=130, bg='royalblue')
inner1am_frame.pack_propagate(False)  # Evita que el frame se ajuste al tamaño del contenido
inner1am_frame.place(x=25, y=150)
inner1am_frame.place_forget()  # Ocultar el frame al inicio

# Añade la imagen al frame
label175 = Label(inner1am_frame, image=photoab)
label175.photo = photoab  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
label175.pack()

photoC1 = PhotoImage(file="Images/Icons/Future/Config/User1.png")  # Carga la imagen desde el mismo directorio que tu script

# Crea un frame llamado inner1ABC_frame
innerC1_frame = tk.Frame(ventanaC1, borderwidth=0, width=130, height=130, bg='royalblue')
innerC1_frame.pack_propagate(False)  # Evita que el frame se ajuste al tamaño del contenido
innerC1_frame.place(x=25, y=150)
innerC1_frame.place_forget()  # Ocultar el frame al inicio

# Añade la imagen al frame
labelC1 = Label(innerC1_frame, image=photoC1)
labelC1.photo = photoC1  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
labelC1.pack()

photoU1 = PhotoImage(file="Images/Icons/Future/Config/Update.png")  # Carga la imagen desde el mismo directorio que tu script

# Crea un frame llamado inner1ABC_frame
innerU1_frame = tk.Frame(ventanaC8, borderwidth=0, width=530, height=130)
innerU1_frame.pack_propagate(False)  # Evita que el frame se ajuste al tamaño del contenido
innerU1_frame.place(x=225, y=50)  # Ocultar el frame al inicio

# Añade la imagen al frame
labelU1 = Label(innerU1_frame, image=photoU1)
labelU1.photo = photoU1  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
labelU1.pack()

##########################################################################

def ML():
    global label
    global color1
    color1 = 'light grey'
    ventanaIS.config(bg=color1)
    ventanaHH.config(bg=color1)
    ventana2.config(bg=color1)
    cuadro_texto.configure(font=("Arial", 32), bg='whitesmoke')
    cuadro1_texto.configure(font=("Arial", 32), bg='whitesmoke')
    cuadro2_texto.configure(font=("Arial", 32), bg='whitesmoke')
    label123n.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)
    RD()

def MD():
    global label123n
    global color1
    color1 = '#141740'
    ventanaIS.config(bg=color1)
    ventanaHH.config(bg=color1)
    ventana2.config(bg=color1)
    cuadro_texto.configure(font=("Arial", 32), bg='light grey')
    cuadro1_texto.configure(font=("Arial", 32), bg='light grey')
    cuadro2_texto.configure(font=("Arial", 32), bg='light grey')
    label123n.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)
    RD()

##########################################################################

cuadro_texto = tk.Entry(ventanaIS, width=26, bd=0, highlightthickness=0, relief='flat')
cuadro_texto.insert(0, 'Escribe aquí un username')
cuadro_texto.bind('<FocusIn>', on_entry_click)
cuadro_texto.bind('<FocusOut>', on_focusout)
cuadro_texto.configure(font=("Arial", 32), bg='whitesmoke')  # Cambia 'blue' y 'white' a los colores que prefieras
cuadro_texto.place(x=820, y=220)

cuadro1_texto = tk.Entry(ventanaIS, width=26, bd=0, highlightthickness=0, relief='flat')
cuadro1_texto.insert(0, 'Escribe aquí la contraseña')
cuadro1_texto.bind('<FocusIn>', on_entry1_click)
cuadro1_texto.bind('<FocusOut>', on_focusout1)
cuadro1_texto.configure(font=("Arial", 32), bg='whitesmoke')
cuadro1_texto.place(x=820, y=350)

cuadro2_texto = tk.Entry(ventana2, width=45, bd=0, highlightthickness=0, relief='flat')
cuadro2_texto.insert(0, 'Escribe aquí la URL, nota si es URL que tenga HTTPS://')
cuadro2_texto.bind('<FocusIn>', on_entry2_click)
cuadro2_texto.bind('<FocusOut>', on_focusout2)
cuadro2_texto.configure(font=("Arial", 32))
cuadro2_texto.place(x=200, y=285)

##########################################################################

def I():
    texto = cuadro_texto.get()
    texto1 = cuadro1_texto.get()
    if texto.strip() == "" or texto1.strip() == "" or texto == 'Escribe aquí un username' or texto1 == 'Escribe aquí la contraseña':
        messagebox.showerror("Error", "El username o contraseña están vacios")
    else:
        messagebox.showinfo("Bienvenido", "Hola de nuevo a HubHubOS, Reanuda tus actividades diarias")
        ventanaHH.deiconify()
        time.sleep(reloj)
        ventanaIS.withdraw()
        RD()

def R():
    texto = cuadro_texto.get()
    texto1 = cuadro1_texto.get()
    if texto.strip() == "" or texto1.strip() == "" or texto == 'Escribe aquí un username' or texto1 == 'Escribe aquí la contraseña':
        messagebox.showerror("Error", "El username o contraseña están vacios")
    else:
        messagebox.showinfo("Bienvenido", "Bienvenido a HubHubOS, Explora un todo un nuevo OS desde cero, :)")
        ventanaHH.deiconify()
        time.sleep(reloj)
        ventanaIS.withdraw()
        RD()

def Back():
    ventanaIS.deiconify()
    time.sleep(reloj)
    ventanaHH.withdraw()
    RD()

def BackA():
    ventanaHH.deiconify()
    time.sleep(reloj)
    ventana2.withdraw()
    RD()

def BackB():
    ventanaHH.deiconify()
    time.sleep(reloj)
    ventanaC1.withdraw()
    ventanaC2.withdraw()
    ventanaC3.withdraw()
    ventanaC4.withdraw()
    ventanaC5.withdraw()
    ventanaC6.withdraw()
    ventanaC7.withdraw()
    ventanaC8.withdraw()
    RD()

def BB():
    global PAP
   
    if PAP == 10:
        PAP = 670
        labeltime1.place(x=1280, y=715)
        labeltime.place(x=1280, y=670)
    
    elif PAP == 670:
        PAP -= 660
        labeltime1.place(x=1280, y=55)
        labeltime.place(x=1280, y=10)

    # Actualizar la posición del marco
    time.sleep(reloj)
    inner1B_frame.place(x=0, y=PAP) 
    botonpaai12.place(x=230, y=PAP) 
    botonpaiH.place(x=0, y=PAP) 
    botonAP1.place(x=110, y=PAP)
    RD()

def C1():
    ventanaC1.withdraw()
    ventanaC1.deiconify()
    time.sleep(reloj)
    ventanaC2.withdraw()
    ventanaC3.withdraw()
    ventanaC4.withdraw()
    ventanaC5.withdraw()
    ventanaC6.withdraw()
    ventanaC7.withdraw()
    ventanaC8.withdraw()
    ventanaC1.deiconify()
    RD()


def C2():
    ventanaC2.withdraw()
    ventanaC2.deiconify()
    time.sleep(reloj)
    ventanaC1.withdraw()
    ventanaC3.withdraw()
    ventanaC4.withdraw()
    ventanaC5.withdraw()
    ventanaC6.withdraw()
    ventanaC7.withdraw()
    ventanaC8.withdraw()
    ventanaC2.deiconify()
    RD()

def C3():
    ventanaC3.withdraw()
    ventanaC3.deiconify()
    time.sleep(reloj)
    ventanaC1.withdraw()
    ventanaC2.withdraw()
    ventanaC4.withdraw()
    ventanaC5.withdraw()
    ventanaC6.withdraw()
    ventanaC7.withdraw()
    ventanaC8.withdraw()
    ventanaC3.deiconify()
    RD()

def C4():
    ventanaC4.withdraw()
    ventanaC4.deiconify()
    time.sleep(reloj)
    ventanaC1.withdraw()
    ventanaC2.withdraw()
    ventanaC3.withdraw()
    ventanaC5.withdraw()
    ventanaC6.withdraw()
    ventanaC7.withdraw()
    ventanaC8.withdraw()
    ventanaC4.deiconify()
    RD()

def C5():
    ventanaC5.withdraw()
    ventanaC5.deiconify()
    time.sleep(reloj)
    ventanaC1.withdraw()
    ventanaC2.withdraw()
    ventanaC3.withdraw()
    ventanaC4.withdraw()
    ventanaC6.withdraw()
    ventanaC7.withdraw()
    ventanaC8.withdraw()
    ventanaC5.deiconify()
    RD()

def C6():
    ventanaC6.withdraw()
    ventanaC6.deiconify()
    time.sleep(reloj)
    ventanaC1.withdraw()
    ventanaC2.withdraw()
    ventanaC3.withdraw()
    ventanaC4.withdraw()
    ventanaC5.withdraw()
    ventanaC7.withdraw()
    ventanaC8.withdraw()
    RD()

def C7():
    ventanaC7.withdraw()
    ventanaC7.deiconify()
    time.sleep(reloj)
    ventanaC1.withdraw()
    ventanaC2.withdraw()
    ventanaC3.withdraw()
    ventanaC4.withdraw()
    ventanaC5.withdraw()
    ventanaC6.withdraw()
    ventanaC8.withdraw()
    RD()

def C8():
    ventanaC8.withdraw()
    ventanaC8.deiconify()
    time.sleep(reloj)
    ventanaC1.withdraw()
    ventanaC2.withdraw()
    ventanaC3.withdraw()
    ventanaC4.withdraw()
    ventanaC5.withdraw()
    ventanaC6.withdraw() 
    ventanaC7.withdraw()
    RD()

def Browser():
    ventana2.deiconify()
    time.sleep(reloj)
    ventanaHH.withdraw()
    RD()

def PantallazoAzul():
    ventanaIS.withdraw()
    ventanaHH.withdraw()
    ventana2.withdraw()
    ventana3.withdraw()
    ventanaC1.withdraw()
    ventanaC2.withdraw()
    ventanaC3.withdraw()
    ventanaC4.withdraw()
    ventanaC5.withdraw()
    ventanaC6.withdraw()
    ventanaC7.withdraw()
    ventanaC8.withdraw()
    ventanaP.withdraw()
    ventanaPA.deiconify()

##########################################################################

# Carga la imagen para el botón

photo_button2 = PhotoImage(file = "Images/Buttons/LightIS.png")

# Crea el botón con la imagen
ColorLightIS1 = Button(ventanaC3, image = photo_button2, bd=0, highlightthickness=0, relief='flat', command=ML)
ColorLightIS1.photo = photo_button2  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
ColorLightIS1.place(x=250, y=325)

# Carga la imagen para el botón
photo_button1 = PhotoImage(file = "Images/Buttons/DarkIS.png")

# Crea el botón con la imagen
ColorDarkIS1 = Button(ventanaC3, image = photo_button1, bd=0, highlightthickness=0, relief='flat', command=MD)
ColorDarkIS1.photo = photo_button1  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
ColorDarkIS1.place(x=370, y=325)

photo_button = PhotoImage(file = "Images/Buttons/LightIS.png")

# Crea el botón con la imagen
ColorLightIS = Button(ventanaIS, image = photo_button, bd=0, highlightthickness=0, relief='flat', command=ML)
ColorLightIS.photo = photo_button  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
ColorLightIS.place(x=1280, y=30)

# Carga la imagen para el botón
photo_button = PhotoImage(file = "Images/Buttons/DarkIS.png")

# Crea el botón con la imagen
ColorDarkIS = Button(ventanaIS, image = photo_button, bd=0, highlightthickness=0, relief='flat', command=MD)
ColorDarkIS.photo = photo_button  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
ColorDarkIS.place(x=1400, y=30)

photo_buttonK = PhotoImage(file = "Images/Buttons/LightIS.png")

# Crea el botón con la imagen
ColorLightIS1 = Button(ventanaC2, image = photo_buttonK, bd=0, highlightthickness=0, relief='flat', command=ML)
ColorLightIS1.photo = photo_buttonK  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
ColorLightIS1.place(x=1180, y=30)

# Carga la imagen para el botón
photo_buttonK2 = PhotoImage(file = "Images/Buttons/DarkIS.png")

# Crea el botón con la imagen
ColorDarkIS1 = Button(ventanaC2, image = photo_buttonK2, bd=0, highlightthickness=0, relief='flat', command=MD)
ColorDarkIS1.photo = photo_buttonK2  # Guarda una referencia de la imagen para evitar que sea recolectada por el recolector de basura
ColorDarkIS1.place(x=1300, y=30)

imagen9 = PhotoImage(file="Images/Buttons/IS.png")

botonpai = tk.Button(ventanaIS, image=imagen9, bd=0, highlightthickness=0, relief='flat', command=I)
botonpai.place(x=810, y=535)

imagen8 = PhotoImage(file="Images/Buttons/RG.png")

botonpai1 = tk.Button(ventanaIS, image=imagen8, bd=0, highlightthickness=0, relief='flat', command=R)
botonpai1.place(x=1170, y=535) 

imagen80 = PhotoImage(file="Images/Buttons/Salir.png")

botonpaai12 = tk.Button(ventanaHH, image=imagen80, bd=0, highlightthickness=0, relief='flat', command=Back)
botonpaai12.place(x=230, y=PAP) 

imagen8012 = PhotoImage(file="Images/Buttons/HubHub.png")

botonpaiH = tk.Button(ventanaHH, image=imagen8012, bg=color1 ,bd=0, highlightthickness=0, relief='flat', command=HH)
botonpaiH.place(x=0, y=PAP) 

def About():
    messagebox.showinfo("HubHubOS Help", "HubHubOS es un Sistema Operativo que es un acompañamiento de Microsoft Windows, Programa creado el 20 de mayo del 2024.                                                            Versión 24B24, Built " + versión)

imagenAP1 = PhotoImage(file="Images/Buttons/Help.png")
botonAP1 = tk.Button(ventanaHH, image=imagenAP1, bd=0, highlightthickness=0, relief='flat', command=About)
botonAP1.place(x=110, y=PAP) 

##########################################################################

imagen812 = PhotoImage(file="Images/Buttons/Calculadora.png")
botonpaiH1 = tk.Button(ventanaHH, image=imagen812, bd=0, highlightthickness=0, relief='flat', command=HCalc)
botonpaiH1C = tk.Button(ventanaC5, image=imagen812, bd=0, highlightthickness=0, relief='flat', command=HCalc)
botonpaiH1C.place(x=250, y=200) 
botonpaiH1.place_forget()

imagen314 = PhotoImage(file="Images/Buttons/HubHubNotDesktop.png")
botonpi = tk.Button(ventanaHH, image=imagen314, bd=0, highlightthickness=0, relief='flat', command=HN)
botonpi.place_forget()
botonpiC = tk.Button(ventanaC5, image=imagen314, bd=0, highlightthickness=0, relief='flat', command=HN)
botonpiC.place(x=380, y=200) 

imagen31 = PhotoImage(file="Images/Buttons/Config.png")
botonpip = tk.Button(ventanaHH, image=imagen31, bd=0, highlightthickness=0, relief='flat', command=HC)
botonpip.place_forget()
botonpipC= tk.Button(ventanaC5, image=imagen31, bd=0, highlightthickness=0, relief='flat', command=HC)
botonpipC.place(x=510, y=200)

imagen32 = PhotoImage(file="Images/Buttons/Paint.png")
botonpaint = tk.Button(ventanaHH, image=imagen32, bd=0, highlightthickness=0, relief='flat', command=HP)
botonpaint.place_forget()
botonpaintC = tk.Button(ventanaC5, image=imagen32, bd=0, highlightthickness=0, relief='flat', command=HP)
botonpaintC.place(x=640, y=200)

imagen33 = PhotoImage(file="Images/Buttons/Pet.png")
botonpet = tk.Button(ventanaHH, image=imagen33, bd=0, highlightthickness=0, relief='flat', command=HP)
botonpet.place_forget()
botonpetC = tk.Button(ventanaC5, image=imagen33, bd=0, highlightthickness=0, relief='flat', command=HP)
botonpetC.place(x=770, y=200)

imagen34 = PhotoImage(file="Images/Buttons/icono_bloc .png")
botonbn = tk.Button(ventanaHH, image=imagen34, bd=0, highlightthickness=0, relief='flat', command=HB)
botonbn.place_forget()
botonbnC = tk.Button(ventanaC5, image=imagen34, bd=0, highlightthickness=0, relief='flat', command=HB)
botonbnC.place(x=250, y=350)

imagen80pn = PhotoImage(file="Images/Buttons/SalirP.png")

botonR1 = tk.Button(ventana2, image=imagen80pn, bd=0, highlightthickness=0, relief='flat', command=BackA)
botonR1.place(x=1440, y=10) 

boton1A1 = tk.Button(ventana2, font=("Arial", 35), text="Search!", fg='white',bg='royalblue', bd=0, highlightthickness=0, relief='flat', width=8, height=1, command=Browser1)
boton1A1.place(x=350, y=550)

boton1A1a = tk.Button(ventana2, font=("Arial", 35), text="Games!", fg='white',bg='royalblue', bd=0, highlightthickness=0, relief='flat', width=8, height=1, command=Gam)
boton1A1a.place(x=850, y=550)

##################################################################Cosas

imagenB1 = PhotoImage(file="Images/Buttons/SalirO.png")

botonpaai121 = tk.Button(ventanaC1, image=imagenB1, bd=0, highlightthickness=0, relief='flat', command=BackB)
botonpaai121.place(x=1440, y=10) 

imagenD1 = PhotoImage(file="Images/Buttons/SalirO.png")

botonD1 = tk.Button(ventanaC2, image=imagenD1, bd=0, highlightthickness=0, relief='flat', command=BackB)
botonD1.place(x=1440, y=10) 

imagenD2 = PhotoImage(file="Images/Buttons/SalirO.png")

botonD2 = tk.Button(ventanaC3, image=imagenD2, bd=0, highlightthickness=0, relief='flat', command=BackB)
botonD2.place(x=1440, y=10)

imagenD3 = PhotoImage(file="Images/Buttons/SalirO.png")

botonD3 = tk.Button(ventanaC4, image=imagenD3, bd=0, highlightthickness=0, relief='flat', command=BackB)
botonD3.place(x=1440, y=10)

imagenD4 = PhotoImage(file="Images/Buttons/SalirO.png")

botonD4 = tk.Button(ventanaC5, image=imagenD4, bd=0, highlightthickness=0, relief='flat', command=BackB)
botonD4.place(x=1440, y=10) 

imagenD5 = PhotoImage(file="Images/Buttons/SalirO.png")

botonD5 = tk.Button(ventanaC6, image=imagenD5, bd=0, highlightthickness=0, relief='flat', command=BackB)
botonD5.place(x=1440, y=10)

imagenD6 = PhotoImage(file="Images/Buttons/SalirO.png")

botonD6 = tk.Button(ventanaC7, image=imagenD6, bd=0, highlightthickness=0, relief='flat', command=BackB)
botonD6.place(x=1440, y=10)

imagenD7 = PhotoImage(file="Images/Buttons/SalirO.png")

botonD7 = tk.Button(ventanaC8, image=imagenD7, bd=0, highlightthickness=0, relief='flat', command=BackB)
botonD7.place(x=1440, y=10)

def a():
    color1 = 'red'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolora = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="red", width=9, height=4, command=a)
botoncolora.place(x=240, y=100) 

def b():
    color1 = 'dark red'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorab = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="dark red", width=9, height=4, command=b)
botoncolorab.place(x=320, y=100)

def c():
    color1 = 'orange'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorac = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="orange", width=9, height=4, command=c)
botoncolorac.place(x=400, y=100)

def d():
    color1 = 'dark orange'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorad = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="dark orange", width=9, height=4, command=d)
botoncolorad.place(x=480, y=100)

def e():
    color1 = 'yellow'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorae = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="yellow", width=9, height=4, command=e)
botoncolorae.place(x=560, y=100) 

def f():
    color1 = 'khaki'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncoloraf = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="khaki", width=9, height=4, command=f)
botoncoloraf.place(x=640, y=100)

def g():
    color1 = 'green'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorag = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="green", width=9, height=4, command=g)
botoncolorag.place(x=720, y=100)

def h():
    color1 = 'dark green'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorah = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="dark green", width=9, height=4, command=h)
botoncolorah.place(x=800, y=100)

def a1():
    color1 = 'light blue'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolora1 = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="light blue", width=9, height=4, command=a1)
botoncolora1.place(x=240, y=200) 

def b1():
    color1 = 'blue'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorab1 = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="blue", width=9, height=4, command=b1)
botoncolorab1.place(x=320, y=200)

def c1():
    color1 = 'dark blue'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorac1 = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="dark blue", width=9, height=4, command=c1)
botoncolorac1.place(x=400, y=200)

def d1():
    color1 = 'purple'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorad1 = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="purple", width=9, height=4, command=d1)
botoncolorad1.place(x=480, y=200)

def e1():
    color1 = 'fuchsia'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorae1 = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="fuchsia", width=9, height=4, command=e1)
botoncolorae1.place(x=560, y=200) 

def f1():
    color1 = 'light pink'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncoloraf1 = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="light pink", width=9, height=4, command=f1)
botoncoloraf1.place(x=640, y=200)

def g1():
    color1 = 'pink'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorag1 = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="pink", width=9, height=4, command=g1)
botoncolorag1.place(x=720, y=200)

def h1():
    color1 = 'black'
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorah1 = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', bg="black", width=9, height=4, command=h1)
botoncolorah1.place(x=800, y=200)

def a2():
    color1 = colorchooser.askcolor()[1]
    ventanaHH.config(bg=color1)
    ventanaIS.config(bg=color1)
    labelbar = Label(inner1B_frame, image=photobar, bg=color1)
    botonpaiH.config(bg=color1)

botoncolorah1 = tk.Button(ventanaC3, bd=0, highlightthickness=0, relief='flat', font=("Arial", 24), text="More Colors", bg="royalblue", fg="whitesmoke", width=9, height=4, command=a2)
botoncolorah1.place(x=880, y=100)

#########################33333

imagenCC1 = PhotoImage(file="Images/Buttons/Configs/Inicio.png")

botonCC1 = tk.Button(ventanaC1, image=imagenCC1, bd=0, highlightthickness=0, relief='flat', command=C1)
botonCC1.place(x=20, y=220) 

imagenCC2 = PhotoImage(file="Images/Buttons/Configs/Sistema.png")

botonCC2 = tk.Button(ventanaC1, image=imagenCC2, bd=0, highlightthickness=0, relief='flat', command=C2)
botonCC2.place(x=20, y=285)

imagenCC3 = PhotoImage(file="Images/Buttons/Configs/Personalización.png")

botonCC3 = tk.Button(ventanaC1, image=imagenCC3, bd=0, highlightthickness=0, relief='flat', command=C3)
botonCC3.place(x=20, y=350)

imagenCC4 = PhotoImage(file="Images/Buttons/Configs/Hora Y Idioma.png")

botonCC4 = tk.Button(ventanaC1, image=imagenCC4, bd=0, highlightthickness=0, relief='flat', command=C4)
botonCC4.place(x=20, y=415)

imagenCC5 = PhotoImage(file="Images/Buttons/Configs/Aplicaciones.png")

botonCC5 = tk.Button(ventanaC1, image=imagenCC5, bd=0, highlightthickness=0, relief='flat', command=C5)
botonCC5.place(x=20, y=480)

imagenCC6 = PhotoImage(file="Images/Buttons/Configs/Juegos.png")

botonCC6 = tk.Button(ventanaC1, image=imagenCC6, bd=0, highlightthickness=0, relief='flat', command=C6)
botonCC6.place(x=20, y=545)

imagenCC7 = PhotoImage(file="Images/Buttons/Configs/Accesibilidad.png")

botonCC7 = tk.Button(ventanaC1, image=imagenCC7, bd=0, highlightthickness=0, relief='flat', command=C7)
botonCC7.place(x=20, y=610)

imagenCC8 = PhotoImage(file="Images/Buttons/Configs/Updates.png")

botonCC8 = tk.Button(ventanaC1, image=imagenCC8, bd=0, highlightthickness=0, relief='flat', command=C8)
botonCC8.place(x=20, y=675)

imagenCC1a = PhotoImage(file="Images/Buttons/Configs/Inicio.png")

botonCC1a = tk.Button(ventanaC2, image=imagenCC1a, bd=0, highlightthickness=0, relief='flat', command=C1)
botonCC1a.place(x=20, y=220) 

imagenCC2a = PhotoImage(file="Images/Buttons/Configs/Sistema.png")

botonCC2a = tk.Button(ventanaC2, image=imagenCC2a, bd=0, highlightthickness=0, relief='flat', command=C2)
botonCC2a.place(x=20, y=285)

imagenCC3a = PhotoImage(file="Images/Buttons/Configs/Personalización.png")

botonCC3a = tk.Button(ventanaC2, image=imagenCC3a, bd=0, highlightthickness=0, relief='flat', command=C3)
botonCC3a.place(x=20, y=350)

imagenCC4a = PhotoImage(file="Images/Buttons/Configs/Hora Y Idioma.png")

botonCC4a = tk.Button(ventanaC2, image=imagenCC4a, bd=0, highlightthickness=0, relief='flat', command=C4)
botonCC4a.place(x=20, y=415)

imagenCC5a = PhotoImage(file="Images/Buttons/Configs/Aplicaciones.png")

botonCC5a = tk.Button(ventanaC2, image=imagenCC5a, bd=0, highlightthickness=0, relief='flat', command=C5)
botonCC5a.place(x=20, y=480)

imagenCC6a = PhotoImage(file="Images/Buttons/Configs/Juegos.png")

botonCC6a = tk.Button(ventanaC2, image=imagenCC6a, bd=0, highlightthickness=0, relief='flat', command=C6)
botonCC6a.place(x=20, y=545)

imagenCC7a = PhotoImage(file="Images/Buttons/Configs/Accesibilidad.png")

botonCC7a = tk.Button(ventanaC2, image=imagenCC7a, bd=0, highlightthickness=0, relief='flat', command=C7)
botonCC7a.place(x=20, y=610)

imagenCC8a = PhotoImage(file="Images/Buttons/Configs/Updates.png")

botonCC8a = tk.Button(ventanaC2, image=imagenCC8a, bd=0, highlightthickness=0, relief='flat', command=C8)
botonCC8a.place(x=20, y=675)

imagenCC1b = PhotoImage(file="Images/Buttons/Configs/Inicio.png")

botonCC1b = tk.Button(ventanaC3, image=imagenCC1b, bd=0, highlightthickness=0, relief='flat', command=C1)
botonCC1b.place(x=20, y=220) 

imagenCC2b = PhotoImage(file="Images/Buttons/Configs/Sistema.png")

botonCC2b = tk.Button(ventanaC3, image=imagenCC2b, bd=0, highlightthickness=0, relief='flat', command=C2)
botonCC2b.place(x=20, y=285)

imagenCC3b = PhotoImage(file="Images/Buttons/Configs/Personalización.png")

botonCC3b = tk.Button(ventanaC3, image=imagenCC3b, bd=0, highlightthickness=0, relief='flat', command=C3)
botonCC3b.place(x=20, y=350)

imagenCC4b = PhotoImage(file="Images/Buttons/Configs/Hora Y Idioma.png")

botonCC4b = tk.Button(ventanaC3, image=imagenCC4b, bd=0, highlightthickness=0, relief='flat', command=C4)
botonCC4b.place(x=20, y=415)

imagenCC5b = PhotoImage(file="Images/Buttons/Configs/Aplicaciones.png")

botonCC5b = tk.Button(ventanaC3, image=imagenCC5b, bd=0, highlightthickness=0, relief='flat', command=C5)
botonCC5b.place(x=20, y=480)

imagenCC6b = PhotoImage(file="Images/Buttons/Configs/Juegos.png")

botonCC6b = tk.Button(ventanaC3, image=imagenCC6b, bd=0, highlightthickness=0, relief='flat', command=C6)
botonCC6b.place(x=20, y=545)

imagenCC7b = PhotoImage(file="Images/Buttons/Configs/Accesibilidad.png")

botonCC7b = tk.Button(ventanaC3, image=imagenCC7b, bd=0, highlightthickness=0, relief='flat', command=C7)
botonCC7b.place(x=20, y=610)

imagenCC8b = PhotoImage(file="Images/Buttons/Configs/Updates.png")

botonCC8b = tk.Button(ventanaC3, image=imagenCC8b, bd=0, highlightthickness=0, relief='flat', command=C8)
botonCC8b.place(x=20, y=675)

imagenCC1c = PhotoImage(file="Images/Buttons/Configs/Inicio.png")

botonCC1c = tk.Button(ventanaC4, image=imagenCC1c, bd=0, highlightthickness=0, relief='flat', command=C1)
botonCC1c.place(x=20, y=220) 

imagenCC2c = PhotoImage(file="Images/Buttons/Configs/Sistema.png")

botonCC2c = tk.Button(ventanaC4, image=imagenCC2c, bd=0, highlightthickness=0, relief='flat', command=C2)
botonCC2c.place(x=20, y=285)

imagenCC3c = PhotoImage(file="Images/Buttons/Configs/Personalización.png")

botonCC3c = tk.Button(ventanaC4, image=imagenCC3c, bd=0, highlightthickness=0, relief='flat', command=C3)
botonCC3c.place(x=20, y=350)

imagenCC4c = PhotoImage(file="Images/Buttons/Configs/Hora Y Idioma.png")

botonCC4c = tk.Button(ventanaC4, image=imagenCC4c, bd=0, highlightthickness=0, relief='flat', command=C4)
botonCC4c.place(x=20, y=415)

imagenCC5c = PhotoImage(file="Images/Buttons/Configs/Aplicaciones.png")

botonCC5c = tk.Button(ventanaC4, image=imagenCC5c, bd=0, highlightthickness=0, relief='flat', command=C5)
botonCC5c.place(x=20, y=480)

imagenCC6c = PhotoImage(file="Images/Buttons/Configs/Juegos.png")

botonCC6c = tk.Button(ventanaC4, image=imagenCC6c, bd=0, highlightthickness=0, relief='flat', command=C6)
botonCC6c.place(x=20, y=545)

imagenCC7c = PhotoImage(file="Images/Buttons/Configs/Accesibilidad.png")

botonCC7c = tk.Button(ventanaC4, image=imagenCC7c, bd=0, highlightthickness=0, relief='flat', command=C7)
botonCC7c.place(x=20, y=610)

imagenCC8c = PhotoImage(file="Images/Buttons/Configs/Updates.png")

botonCC8c = tk.Button(ventanaC4, image=imagenCC8c, bd=0, highlightthickness=0, relief='flat', command=C8)
botonCC8c.place(x=20, y=675)

imagenCC1d = PhotoImage(file="Images/Buttons/Configs/Inicio.png")

botonCC1d = tk.Button(ventanaC5, image=imagenCC1d, bd=0, highlightthickness=0, relief='flat', command=C1)
botonCC1d.place(x=20, y=220) 

imagenCC2d = PhotoImage(file="Images/Buttons/Configs/Sistema.png")

botonCC2d = tk.Button(ventanaC5, image=imagenCC2d, bd=0, highlightthickness=0, relief='flat', command=C2)
botonCC2d.place(x=20, y=285)

imagenCC3d = PhotoImage(file="Images/Buttons/Configs/Personalización.png")

botonCC3d = tk.Button(ventanaC5, image=imagenCC3d, bd=0, highlightthickness=0, relief='flat', command=C3)
botonCC3d.place(x=20, y=350)

imagenCC4d = PhotoImage(file="Images/Buttons/Configs/Hora Y Idioma.png")

botonCC4d = tk.Button(ventanaC5, image=imagenCC4d, bd=0, highlightthickness=0, relief='flat', command=C4)
botonCC4d.place(x=20, y=415)

imagenCC5d = PhotoImage(file="Images/Buttons/Configs/Aplicaciones.png")

botonCC5d = tk.Button(ventanaC5, image=imagenCC5d, bd=0, highlightthickness=0, relief='flat', command=C5)
botonCC5d.place(x=20, y=480)

imagenCC6d = PhotoImage(file="Images/Buttons/Configs/Juegos.png")

botonCC6d = tk.Button(ventanaC5, image=imagenCC6d, bd=0, highlightthickness=0, relief='flat', command=C6)
botonCC6d.place(x=20, y=545)

imagenCC7d = PhotoImage(file="Images/Buttons/Configs/Accesibilidad.png")

botonCC7d = tk.Button(ventanaC5, image=imagenCC7d, bd=0, highlightthickness=0, relief='flat', command=C7)
botonCC7d.place(x=20, y=610)

imagenCC8d = PhotoImage(file="Images/Buttons/Configs/Updates.png")

botonCC8d = tk.Button(ventanaC5, image=imagenCC8d, bd=0, highlightthickness=0, relief='flat', command=C8)
botonCC8d.place(x=20, y=675)

imagenCC1e = PhotoImage(file="Images/Buttons/Configs/Inicio.png")

botonCC1e = tk.Button(ventanaC6, image=imagenCC1e, bd=0, highlightthickness=0, relief='flat', command=C1)
botonCC1e.place(x=20, y=220) 

imagenCC2e = PhotoImage(file="Images/Buttons/Configs/Sistema.png")

botonCC2e = tk.Button(ventanaC6, image=imagenCC2e, bd=0, highlightthickness=0, relief='flat', command=C2)
botonCC2e.place(x=20, y=285)

imagenCC3e = PhotoImage(file="Images/Buttons/Configs/Personalización.png")

botonCC3e = tk.Button(ventanaC6, image=imagenCC3e, bd=0, highlightthickness=0, relief='flat', command=C3)
botonCC3e.place(x=20, y=350)

imagenCC4e = PhotoImage(file="Images/Buttons/Configs/Hora Y Idioma.png")

botonCC4e = tk.Button(ventanaC6, image=imagenCC4e, bd=0, highlightthickness=0, relief='flat', command=C4)
botonCC4e.place(x=20, y=415)

imagenCC5e = PhotoImage(file="Images/Buttons/Configs/Aplicaciones.png")

botonCC5e = tk.Button(ventanaC6, image=imagenCC5e, bd=0, highlightthickness=0, relief='flat', command=C5)
botonCC5e.place(x=20, y=480)

imagenCC6e = PhotoImage(file="Images/Buttons/Configs/Juegos.png")

botonCC6e = tk.Button(ventanaC6, image=imagenCC6e, bd=0, highlightthickness=0, relief='flat', command=C6)
botonCC6e.place(x=20, y=545)

imagenCC7e = PhotoImage(file="Images/Buttons/Configs/Accesibilidad.png")

botonCC7e = tk.Button(ventanaC6, image=imagenCC7e, bd=0, highlightthickness=0, relief='flat', command=C7)
botonCC7e.place(x=20, y=610)

imagenCC8e = PhotoImage(file="Images/Buttons/Configs/Updates.png")

botonCC8e = tk.Button(ventanaC6, image=imagenCC8e, bd=0, highlightthickness=0, relief='flat', command=C8)
botonCC8e.place(x=20, y=675)

imagenCC1f = PhotoImage(file="Images/Buttons/Configs/Inicio.png")

botonCC1f = tk.Button(ventanaC7, image=imagenCC1f, bd=0, highlightthickness=0, relief='flat', command=C1)
botonCC1f.place(x=20, y=220) 

imagenCC2f = PhotoImage(file="Images/Buttons/Configs/Sistema.png")

botonCC2f = tk.Button(ventanaC7, image=imagenCC2f, bd=0, highlightthickness=0, relief='flat', command=C2)
botonCC2f.place(x=20, y=285)

imagenCC3f = PhotoImage(file="Images/Buttons/Configs/Personalización.png")

botonCC3f = tk.Button(ventanaC7, image=imagenCC3f, bd=0, highlightthickness=0, relief='flat', command=C3)
botonCC3f.place(x=20, y=350)

imagenCC4f = PhotoImage(file="Images/Buttons/Configs/Hora Y Idioma.png")

botonCC4f = tk.Button(ventanaC7, image=imagenCC4f, bd=0, highlightthickness=0, relief='flat', command=C4)
botonCC4f.place(x=20, y=415)

imagenCC5f = PhotoImage(file="Images/Buttons/Configs/Aplicaciones.png")

botonCC5f = tk.Button(ventanaC7, image=imagenCC5f, bd=0, highlightthickness=0, relief='flat', command=C5)
botonCC5f.place(x=20, y=480)

imagenCC6f = PhotoImage(file="Images/Buttons/Configs/Juegos.png")

botonCC6f = tk.Button(ventanaC7, image=imagenCC6f, bd=0, highlightthickness=0, relief='flat', command=C6)
botonCC6f.place(x=20, y=545)

imagenCC7f = PhotoImage(file="Images/Buttons/Configs/Accesibilidad.png")

botonCC7f = tk.Button(ventanaC7, image=imagenCC7f, bd=0, highlightthickness=0, relief='flat', command=C7)
botonCC7f.place(x=20, y=610)

imagenCC8f = PhotoImage(file="Images/Buttons/Configs/Updates.png")

botonCC8f = tk.Button(ventanaC7, image=imagenCC8f, bd=0, highlightthickness=0, relief='flat', command=C8)
botonCC8f.place(x=20, y=675)

imagenCC1g = PhotoImage(file="Images/Buttons/Configs/Inicio.png")

botonCC1g = tk.Button(ventanaC8, image=imagenCC1g, bd=0, highlightthickness=0, relief='flat', command=C1)
botonCC1g.place(x=20, y=220) 

imagenCC2g = PhotoImage(file="Images/Buttons/Configs/Sistema.png")

botonCC2g = tk.Button(ventanaC8, image=imagenCC2g, bd=0, highlightthickness=0, relief='flat', command=C2)
botonCC2g.place(x=20, y=285)

imagenCC3g = PhotoImage(file="Images/Buttons/Configs/Personalización.png")

botonCC3g = tk.Button(ventanaC8, image=imagenCC3g, bd=0, highlightthickness=0, relief='flat', command=C3)
botonCC3g.place(x=20, y=350)

imagenCC4g = PhotoImage(file="Images/Buttons/Configs/Hora Y Idioma.png")

botonCC4g = tk.Button(ventanaC8, image=imagenCC4g, bd=0, highlightthickness=0, relief='flat', command=C4)
botonCC4g.place(x=20, y=415)

imagenCC5g = PhotoImage(file="Images/Buttons/Configs/Aplicaciones.png")

botonCC5g = tk.Button(ventanaC8, image=imagenCC5g, bd=0, highlightthickness=0, relief='flat', command=C5)
botonCC5g.place(x=20, y=480)

imagenCC6g = PhotoImage(file="Images/Buttons/Configs/Juegos.png")

botonCC6g = tk.Button(ventanaC8, image=imagenCC6g, bd=0, highlightthickness=0, relief='flat', command=C6)
botonCC6g.place(x=20, y=545)

imagenCC7g = PhotoImage(file="Images/Buttons/Configs/Accesibilidad.png")

botonCC7g = tk.Button(ventanaC8, image=imagenCC7g, bd=0, highlightthickness=0, relief='flat', command=C7)
botonCC7g.place(x=20, y=610)

imagenCC8g = PhotoImage(file="Images/Buttons/Configs/Updates.png")

botonCC8g = tk.Button(ventanaC8, image=imagenCC8g, bd=0, highlightthickness=0, relief='flat', command=C8)
botonCC8g.place(x=20, y=675)

#more defs for configs

def Delete():
    
    file = "Code/Code/HubHubOS.py"
    response = messagebox.askyesno("HubHubOS", "¿Estás seguro que quieres desistalar HubHubOS?")
    if response:
        global bye
        os.remove(__file__)
        messagebox.showwarning("HubHubOS", "HubHubOS ha sido desistalado y tu equipo será reiniciado para culminar el proceso")
        os.system("shutdown /r /t 15")
       
        ventanaC7.withdraw()
        ventana3.deiconify()

    else:
        messagebox.showerror("HubHubOS mistake", "No se pudo eliminar HubHubOS")

imagenBC1 = PhotoImage(file="Images/Buttons/Configs/BC1.png")

botonBC1 = tk.Button(ventanaC7, image=imagenBC1, bd=0, highlightthickness=0, relief='flat', command=Delete)
botonBC1.place(x=300, y=100)

###########################################################################Para configs

EX = 180
EY = 180

PC1 = PhotoImage(file="Images/Icons/Future/Config/User1.png")
FC1 = tk.Frame(ventanaC1, bd=0, highlightthickness=0, relief='flat', width=EX, height=EY, bg='royalblue')
FC1.pack_propagate(False)
FC1.place(x=20, y=20)
LC1 = Label(FC1, image=PC1)
LC1.photo = PC1
LC1.pack()

PC2 = PhotoImage(file="Images/Icons/Future/Config/User1.png")
FC2 = tk.Frame(ventanaC2, bd=0, highlightthickness=0, relief='flat', width=EX, height=EY, bg='royalblue')
FC2.pack_propagate(False)
FC2.place(x=20, y=20)
LC2 = Label(FC2, image=PC2)
LC2.photo = PC2
LC2.pack()

PC3 = PhotoImage(file="Images/Icons/Future/Config/User1.png")
FC3 = tk.Frame(ventanaC3, bd=0, highlightthickness=0, relief='flat', width=EX, height=EY, bg='royalblue')
FC3.pack_propagate(False)
FC3.place(x=20, y=20)
LC3 = Label(FC3, image=PC3)
LC3.photo = PC3
LC3.pack()

PC4 = PhotoImage(file="Images/Icons/Future/Config/User1.png")
FC4 = tk.Frame(ventanaC4, bd=0, highlightthickness=0, relief='flat', width=EX, height=EY, bg='royalblue')
FC4.pack_propagate(False)
FC4.place(x=20, y=20)
LC4 = Label(FC4, image=PC4)
LC4.photo = PC4
LC4.pack()

PC5 = PhotoImage(file="Images/Icons/Future/Config/User1.png")
FC5 = tk.Frame(ventanaC5, bd=0, highlightthickness=0, relief='flat', width=EX, height=EY, bg='royalblue')
FC5.pack_propagate(False)
FC5.place(x=20, y=20)
LC5 = Label(FC5, image=PC5)
LC5.photo = PC5
LC5.pack()

PC6 = PhotoImage(file="Images/Icons/Future/Config/User1.png")
FC6 = tk.Frame(ventanaC6, bd=0, highlightthickness=0, relief='flat', width=EX, height=EY, bg='royalblue')
FC6.pack_propagate(False)
FC6.place(x=20, y=20)
LC6 = Label(FC6, image=PC6)
LC6.photo = PC6
LC6.pack()

PC7 = PhotoImage(file="Images/Icons/Future/Config/User1.png")
FC7 = tk.Frame(ventanaC7, bd=0, highlightthickness=0, relief='flat', width=EX, height=EY, bg='royalblue')
FC7.pack_propagate(False)
FC7.place(x=20, y=20)
LC7 = Label(FC7, image=PC7)
LC7.photo = PC7
LC7.pack()

PC8 = PhotoImage(file="Images/Icons/Future/Config/User1.png")
FC8 = tk.Frame(ventanaC8, bd=0, highlightthickness=0, relief='flat', width=EX, height=EY, bg='royalblue')
FC8.pack_propagate(False)
FC8.place(x=20, y=20)
LC8 = Label(FC8, image=PC8)
LC8.photo = PC8
LC8.pack()

###########################################################################

imagen801 = PhotoImage(file="Images/Buttons/Descartado/BB.png")

botonpai12 = tk.Button(ventanaC1, image=imagen801, bd=0, highlightthickness=0, relief='flat', command=BB)
botonpai12.place(x=1300, y=PAP) 

def Update():
    webbrowser.open(web)

botonpCB2 = tk.Button(ventanaC8, font=('Arial', 30), bg='royalblue', fg='whitesmoke', text="Buscar actualizaciones", bd=0, highlightthickness=0, relief='flat', width=18, height=1,command=Update)
botonpCB2.place(x=240, y=180) 

##########################3

def on_entry_click(event):
    if uadro_texto.get() == 'Escribe el valor vértical':
        uadro_texto.delete(0, "end") # elimina el texto predeterminado
        uadro_texto.config(fg='black')

def on_focusout(event):
    if uadro_texto.get() == '':
        uadro_texto.insert(0, 'Escribe el valor véritcal') # reinserta el texto predeterminado
        uadro_texto.config(fg='grey')

def on_entry1_click(event):
    if uadro1_texto.get() == 'Escribe el valor horizontal':
        uadro1_texto.delete(0, "end") # elimina el texto predeterminado
        uadro1_texto.config(fg='black')

def on_focusout1(event):
    if uadro1_texto.get() == '':
        uadro1_texto.insert(0, 'Escribe el valor horizontal') # reinserta el texto predeterminado
        uadro1_texto.config(fg='grey')


uadro_texto = tk.Entry(ventanaC3, width=26)
uadro_texto.insert(0, 'Escribe el valor vértical')
uadro_texto.bind('<FocusIn>', on_entry_click)
uadro_texto.bind('<FocusOut>', on_focusout)
uadro_texto.configure(font=("Arial", 32), bg='whitesmoke')
uadro_texto.place(x=250, y=500)

uadro1_texto = tk.Entry(ventanaC3, width=26)
uadro1_texto.insert(0, 'Escribe el valor horizontal')
uadro1_texto.bind('<FocusIn>', on_entry1_click)
uadro1_texto.bind('<FocusOut>', on_focusout1)
uadro1_texto.configure(font=("Arial", 32), bg='whitesmoke')
uadro1_texto.place(x=250, y=580)

##########################

def Sizes():
    try:
        vertical = int(uadro_texto.get())
        horizontal = int(uadro1_texto.get())
        if vertical > 0 and horizontal > 0:
            size = f"{horizontal}x{vertical}"
            ventanaIS.geometry(size)
            ventanaHH.geometry(size)
            ventana2.geometry(size)
            ventana3.geometry(size)
            ventanaP.geometry(size)
            ventanaC1.geometry(size)
            ventanaC2.geometry(size)
            ventanaC3.geometry(size)
            ventanaC4.geometry(size)
            ventanaC5.geometry(size)
            ventanaC6.geometry(size)
            ventanaC7.geometry(size)
            ventanaC8.geometry(size) 
            ventanaP.geometry(size)
            ventanaPA.geometry(size)
            ventanaPA2.geometry(size)
            RD()   
        else:
            messagebox.showerror("HubHubOS Error", "Por favor, ingresa solo números enteros positivos.")
    except ValueError:
        messagebox.showerror("HubHubOS Error", "Por favor, ingresa solo números enteros positivos.")

#########################################################3

botonpCB3 = tk.Button(ventanaC3, font=('Arial', 30), bg='royalblue', fg='whitesmoke', text="Actualizar tamaño", bd=0, highlightthickness=0, relief='flat', width=18, height=1,command=Sizes)
botonpCB3.place(x=250, y=660) 

###############################Time

def realizar_operaciones():
    contador = 0
    inicio = time.time()
    
    # Realizar operaciones hasta que haya pasado un segundo
    while time.time() - inicio < .01:
        #Ejemplo de operación matemática simple
        operacion = 2 + 2
        contador += 1
    
    if contador < 5000:
        messagebox.showwarning("HubHubOS Error", f"Al parecer el rendimiento de tu equipo ha bajado")

    elif contador < 75 * necesary:
        messagebox.showerror("HubHubOS Error", f"Error de CPU / RAM, volcando memoria")
        PantallazoAzul()

    else:
        pass

# Llamar a la función
realizar_operaciones()

def RD():  #RD no se debe cambiar su nombre
    realizar_operaciones()

#################################Reloj

chart = False

def tiempo():
    time = strftime('%I:%M:%S %p')
    labeltime.config(text = time)
    labeltime.after(1000, tiempo)

def Fecha():   
    if chart == False:
        fecha = strftime("%d/%m/%Y")  # Asegúrate de usar minúsculas para día y mes
        labeltime1.config(text=fecha)
        labeltime1.after(1000, Fecha)  # Pasa la función Fecha, no la cadena fecha
    
    else:
        fecha = strftime('%m/%d/%Y')
        labeltime1.config(text=fecha)
        labeltime1.after(1000, Fecha)

def for1():
    global chart
    if chart == False:
        chart = True
    else: 
        chart = False

labeltime1 = tk.Label(ventanaHH, font = ('calibri', 30, 'bold'), background = 'royalblue', foreground = 'white', text=Fecha)
labeltime1.place(x=1280, y=715)

labeltime = tk.Label(ventanaHH, font = ('calibri', 30, 'bold'), background = 'royalblue', foreground = 'white', text=tiempo)
labeltime.place(x=1280, y=670)

tiempo()
Fecha()

botonfecha1 = tk.Button(ventanaC4, font=('Arial', 30), bg='royalblue', fg='whitesmoke', text="Formato Inglés/Mundial", bd=0, highlightthickness=0, relief='flat', width=18, height=1, command=for1)
botonfecha1.place(x=240, y=50) 

####################################OFFICE1

OfficeAlpha = PhotoImage(file="Images/Menus/Office.png")

Office1 = tk.Frame(ventanaC1, borderwidth=0, width=500, height=250)
Office1.pack_propagate(False)
Office1.place(x=235, y=50)

OfficeA = Label(Office1, image=OfficeAlpha)
OfficeA.photo = OfficeAlpha
OfficeA.pack()

def Office():
    pass

botonCB1 = tk.Button(ventanaC1, font=('Arial', 30), bg='royalblue', fg='whitesmoke', text="Pruebalo", bd=0, highlightthickness=0, relief='flat', width=18, height=1, command=Office)
botonCB1.place(x=235, y=320) 

###################33################3#

ventanaIS.mainloop()

#####################################The end

####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
####################################################################################################################################################
