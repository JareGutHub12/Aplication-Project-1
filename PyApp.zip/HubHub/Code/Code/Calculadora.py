import tkinter as tk
import math
from tkinter import Tk, Canvas
from tkinter import messagebox

ventana = tk.Tk()
ventana.geometry('630x700')
ventana.title("Calculadora")
ventana.configure(bg='#363636')

inner1_frame = tk.Frame(ventana, width=610, height=50, bg='#363636')  # Color oscuro
inner1_frame.pack_propagate(False)  # Evita que el frame se ajuste al tamaño del contenido
inner1_frame.place(x=30, y=200)
inner1_frame.pack()

num = 0
num2 = 0
operation = ""
capacity = 1
multiply = 10
decimal = False

def pre1():
    global num
    global numero
    global capacity
    num = num * multiply + 1 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)


def pre2():
    global num
    global numero
    global capacity
    num = num * multiply + 2 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)

def pre0():
    global num
    global numero
    global capacity  # Añade esta línea
    num = num * multiply + 0 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)

def pre3():
    global num
    global numero
    global capacity
    num = num * multiply + 3 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)

def pre4():
    global num
    global numero
    global capacity
    num = num * multiply + 4 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)

def pre5():
    global num
    global numero
    global capacity
    num = num * multiply + 5 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)

def pre6():
    global num
    global numero
    global capacity
    num = num * multiply + 6 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)

def pre7():
    global num
    global numero
    global capacity
    num = num * multiply + 7 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)

def pre8():
    global num
    global numero
    global capacity
    num = num * multiply + 8 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)

def pre9():
    global num
    global numero
    global capacity
    num = num * multiply + 9 * capacity
    if decimal:
        capacity /= 10
    if len(str(num)) > 15:
        numero.set("Muy grande")
    else:
        numero.set(num)

numero = tk.StringVar(value=num)

def bob():
    global num
    global numero
    global capacity
    num = 0
    decimal = False
    capacity = 1
    numero.set(num)

def presig():
    global num
    global numero
    num = num * -1
    numero.set(num)

def preπ():
    global num
    global numero
    num = 3.14159265358979
    global capacity
    capacity = 1
    numero.set(num)

def pree():
    global num
    global numero
    num = 2.71828182845904
    global capacity
    capacity = 1
    numero.set(num)

def pre_decimal():
    global multiply
    global capacity
    global decimal
    if not decimal:
        decimal = True
        multiply = 1
        capacity = capacity * 0.1

# Funciones para los botones de los números
def pre_number(n):
    global num
    num = num * 10 + n
    numero.set(num)

# Funciones para los botones de las operaciones
def pre_sum():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    operation = "add"

def pre_subtract():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    operation = "subtract"

def por():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    operation = "por"

def pur():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    operation = "pur"

def par():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    operation = "par"

def fe():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    operation = "fe"

def pir():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    num = 10 ** num2
    num = round(num, 8)
    numero.set(num)

def fact():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    num = math.gamma(num2 + 1)
    num = round(num, 8)
    numero.set(num)

def fat():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    num = math.log(num2)
    num = round(num, 8)
    numero.set(num)

def fate():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    num = num2 ** .5
    num = round(num, 8)
    numero.set(num)

def fete():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    num = num2 ** 2
    numero.set(num)

def f1():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    angulo_radianes = math.radians(num2)
     # Calcular seno, coseno y tangente
    num = math.sin(angulo_radianes)
    num = round(num, 8)
    numero.set(num)
def f2():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    angulo_radianes = math.radians(num2)
     # Calcular seno, coseno y tangente
    num = round(num, 8)
    num = math.cos(angulo_radianes)
    numero.set(num)
def f3():
    global num, num2, operation
    global capacity
    capacity = 1
    num2 = num
    num = 0
    angulo_radianes = math.radians(num2)
     # Calcular seno, coseno y tangente
    num = math.tan(angulo_radianes)
    num = round(num, 8)
    numero.set(num)
    
# Función para el botón de igual
def pre_equal():
    global num, num2, operation
    if operation == "add":
        num = num + num2
        num = round(num, 8)
    elif operation == "subtract":
        num = num2 - num
        num = round(num, 8)
    elif operation == "por":
        num = num * num2
        num = round(num, 8)
    elif operation == "pur":
        num = num2 / num
        num = round(num, 8)
    elif operation == "par":
        num = num2 ** num
        num = round(num, 8)
    elif operation == "fe":
        num = math.log(num2, num)
        num = round(num, 8)
    numero.set(num)
    operation = ""

inner_frame = tk.Frame(ventana, width=600, height=100, bg='#363636')  # Color oscuro
inner_frame.pack_propagate(False)  # Evita que el frame se ajuste al tamaño del contenido
inner_frame.pack()

    # Crea una etiqueta que usa la variable 'numero'
label = tk.Label(inner_frame, textvariable=numero, fg='white', bg='#363636', font=("Arial", 45))
label.place(x=20, y=50)
label.pack(expand=True)

# Crea un botón para cambiar el número
def change_number(new_value):
    numero.set(new_value)

boton = tk.Button(ventana, font=("Arial", 26), text="π", fg='white',bg='dim grey', width=5, height=1, command=preπ)
boton.place(x=130, y=290)

boton1 = tk.Button(ventana, font=("Arial", 26), text="e", fg='white', bg='dim grey', width=5, height=1, command=pree)
boton1.place(x=250, y=290)

botonba = tk.Button(ventana, font=("Arial", 26), text="x²", fg='white',bg='dim grey', width=5, height=1, command=fete)
botonba.place(x=10, y=210)

boton1ba = tk.Button(ventana, font=("Arial", 26), text="²√x", fg='white', bg='dim grey', width=5, height=1, command=fate)
boton1ba.place(x=10, y=290)

boton2 = tk.Button(ventana, font=("Arial", 26), text="x^y", fg='white', bg='dim grey', width=5, height=1, command=par)
boton2.place(x=10, y=370)

boton3 = tk.Button(ventana, font=("Arial", 26), text="10^x", fg='white', bg='dim grey', width=5, height=1, command=pir)
boton3.place(x=10, y=450)

boton4 = tk.Button(ventana, font=("Arial", 26), text="log", fg='white', bg='dim grey', width=5, height=1, command=fe)
boton4.place(x=10, y=530)

boton5 = tk.Button(ventana, font=("Arial", 26), text="ln", fg='white', bg='dimgrey', width=5, height=1, command=fat)
boton5.place(x=10, y=610)

boton6 = tk.Button(ventana, font=("Arial", 26), text="sen", fg='white', bg='dimgrey', width=5, height=1, command=f1)
boton6.place(x=130, y=210)

boton7 = tk.Button(ventana, font=("Arial", 26), text="cos", fg='white', bg='dimgrey', width=5, height=1, command=f2)
boton7.place(x=250, y=210)

boton8 = tk.Button(ventana, font=("Arial", 26), text="tan", fg='white', bg='dimgrey', width=5, height=1, command=f3)
boton8.place(x=370, y=210)

boton9 = tk.Button(ventana, font=("Arial", 26), text="C",  fg='white',bg='dimgrey', width=5, height=1, command=bob)
boton9.place(x=490, y=210)

boton8a = tk.Button(ventana, font=("Arial", 26), text="n!",  fg='white',bg='dimgrey', width=5, height=1, command=fact)
boton8a.place(x=370, y=290)

boton9a = tk.Button(ventana, font=("Arial", 26), text="÷",  fg='white',bg='dimgrey', width=5, height=1, command=pur)
boton9a.place(x=490, y=290)

boton6b = tk.Button(ventana, font=("Arial",  26), text="7",  fg='white',bg='dimgrey', width=5, height=1, command=pre7)
boton6b.place(x=130, y=370)

boton7b = tk.Button(ventana, font=("Arial", 26), text="8",  fg='white',bg='dimgrey', width=5, height=1, command=pre8)
boton7b.place(x=250, y=370)

boton8b = tk.Button(ventana, font=("Arial", 26), text="9", fg='white',bg='dimgrey', width=5, height=1, command=pre9)
boton8b.place(x=370, y=370)

boton9b = tk.Button(ventana, font=("Arial", 26), text="x", fg='white', bg='dimgrey', width=5, height=1, command=por)
boton9b.place(x=490, y=370)

boton6bc = tk.Button(ventana, font=("Arial", 26), text="4", fg='white', bg='dimgrey', width=5, height=1, command=pre4)
boton6bc.place(x=130, y=450)

boton7bc = tk.Button(ventana, font=("Arial", 26), text="5", fg='white', bg='dimgrey', width=5, height=1, command=pre5)
boton7bc.place(x=250, y=450)

boton8bc = tk.Button(ventana, font=("Arial", 26), text="6", fg='white', bg='dimgrey', width=5, height=1, command=pre6)
boton8bc.place(x=370, y=450)

boton9bc = tk.Button(ventana, font=("Arial", 26), text="-", fg='white', bg='dimgrey', width=5, height=1, command=pre_subtract)
boton9bc.place(x=490, y=450)

boton6bs = tk.Button(ventana, font=("Arial", 26), text="1", fg='white', bg='dimgrey', width=5, height=1, command=pre1)
boton6bs.place(x=130, y=530)

boton7bs = tk.Button(ventana, font=("Arial", 26), text="2", fg='white', bg='dimgrey', width=5, height=1, command=pre2)
boton7bs.place(x=250, y=530)

boton8bs = tk.Button(ventana, font=("Arial", 26), text="3", fg='white', bg='dimgrey', width=5, height=1, command=pre3)
boton8bs.place(x=370, y=530)

boton9bs = tk.Button(ventana, font=("Arial", 26), text="+", fg='white', bg='dimgrey', width=5, height=1, command=pre_sum)
boton9bs.place(x=490, y=530)

boton6bcs = tk.Button(ventana, font=("Arial", 26), text="+/-", fg='white', bg='dimgrey', width=5, height=1,  command=presig)
boton6bcs.place(x=130, y=610)

boton7bcs = tk.Button(ventana, font=("Arial", 26), text="0", fg='white', bg='dimgrey', width=5, height=1, command=pre0)
boton7bcs.place(x=250, y=610)

boton8bcs = tk.Button(ventana, font=("Arial", 26), text=".", fg='white', bg='dimgrey', width=5, height=1, command=pre_decimal)
boton8bcs.place(x=370, y=610)

boton9bcs = tk.Button(ventana, font=("Arial", 26), text="=", fg='white', bg='#26C3E8', width=5, height=1, command=pre_equal)
boton9bcs.place(x=490, y=610)

messagebox.showwarning("Anuncio importante", f"Solo puedes hacer una operación a la vez como 3+3 o 9*9")

ventana.mainloop()