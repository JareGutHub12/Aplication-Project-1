from tkinter import  Canvas, PhotoImage, Tk, Frame, Button,messagebox, filedialog, Scale, HORIZONTAL,ALL, colorchooser
import PIL.ImageGrab as ImageGrab

linea_x = 0
linea_y = 0
color = 'black'

stilen = 0

def linea_xy(event):
	global linea_x
	global linea_y

	linea_x = event.x
	linea_y = event.y 

def linea1(event):
    global linea_x, linea_y
    canvas.create_line((linea_x, linea_y, event.x, event.y), fill=color, width=espesor_pincel.get(), smooth=True)
    linea_x = event.x
    linea_y = event.y

def linea2(event):
    global linea_x, linea_y
    grosor = espesor_pincel.get()
    dx = event.x - linea_x
    dy = event.y - linea_y
    dist = ((dx ** 2) + (dy ** 2)) ** 0.5
    for i in range(int(dist)):
        x = linea_x + (i / dist) * dx
        y = linea_y + (i / dist) * dy
        canvas.create_oval(x - grosor / 2, y - grosor / 2, x + grosor / 2, y + grosor / 2, fill=color, outline=color)
    linea_x = event.x
    linea_y = event.y

def stile():
	global stilen
	if stilen == 1:
		canvas.bind('<B1-Motion>', linea1)
		stilen = 0

	elif stilen == 0:
		canvas.bind('<B1-Motion>', linea2)
		stilen = 1

def mostrar_color(nueva_color):
	global color 
	color = nueva_color


def borrar():
	global color
	color = 'Whitesmoke'


def limpiar():
	canvas.delete(ALL)

def colorch():
    global color
    color = colorchooser.askcolor()[1]

def salir():
	ventana.destroy()
	ventana.quit()

def guardar_dibujo():

	try: 
		filename = filedialog.asksaveasfilename(defaultextension='.png')

		x = ventana.winfo_rootx() + canvas.winfo_x()
		y = (ventana.winfo_rooty() + canvas.winfo_y())

		x1 = x + canvas.winfo_width()
		y1 = y + canvas.winfo_height()

		ImageGrab.grab().crop((x, y, x1, y1)).save(filename)
		messagebox.showinfo('Guardar Dibujo','Imagen guardada en: ' + str(filename) )
	except:
		messagebox.showerror('Guardar Dibujo', 'Imagen no guardada\n Error')

ventana = Tk()
ventana.state('zoomed')
ventana.config(bg='royalblue')
ventana.title('HubHubOS paint')

ventana.rowconfigure(0, weight=1)
ventana.columnconfigure(0, weight=1)

# frame principal comandos  y canvas de dibujo

frame = Frame(ventana, bg='royalblue', height=200)
frame.grid(column =0, row =0, sticky='ew')

frame.columnconfigure(0, minsize=200, weight=1)


# canvas de dibujo 
canvas = Canvas(ventana,  height=660 , bg= 'whitesmoke' )
canvas.grid(row=1,column=0, sticky='nsew')


canvas.rowconfigure(0,weight=1)
canvas.columnconfigure(0, weight=1, minsize=100)

canvas.bind('<Button-1>', linea_xy)
canvas.bind('<B1-Motion>', linea2)


# Canvas para colores 

canvas_colores = Canvas(frame, bg='royalblue', width=5,  height=40)
canvas_colores.grid(column =0, row =0, sticky='ew', padx=1, pady=1)
canvas_colores.config(relief='flat')


id = canvas_colores.create_rectangle((10,10,30,30),fill ='red')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('red'))

id = canvas_colores.create_rectangle((40,10,60,30),fill ='green')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('green'))

id = canvas_colores.create_rectangle((70,10,90,30),fill ='yellow')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('yellow'))

id = canvas_colores.create_rectangle((100,10,120,30),fill ='magenta')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('magenta'))

id = canvas_colores.create_rectangle((130,10,150,30),fill ='blue')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('blue'))

id = canvas_colores.create_rectangle((160,10,180,30),fill ='orange')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('orange'))

id = canvas_colores.create_rectangle((190,10,210,30),fill ='salmon')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('salmon'))

id = canvas_colores.create_rectangle((220,10,240,30),fill ='sky blue')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('sky blue'))

id = canvas_colores.create_rectangle((250,10,270,30),fill ='gold')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('gold'))

id = canvas_colores.create_rectangle((280,10,300,30),fill ='hot pink')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('hot pink'))

id = canvas_colores.create_rectangle((310,10,330,30),fill ='bisque')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('bisque'))

id = canvas_colores.create_rectangle((340,10,360,30),fill ='brown4')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('brown4'))

id = canvas_colores.create_rectangle((370,10,390,30),fill ='gray')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('gray'))

id = canvas_colores.create_rectangle((400,10,420,30),fill ='purple')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('purple'))

id = canvas_colores.create_rectangle((430,10,450,30),fill ='green2')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('green2'))

id = canvas_colores.create_rectangle((460,10,480,30),fill ='dodger blue')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('dodger blue'))

id = canvas_colores.create_rectangle((490,10,510,30),fill ='black')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('black'))

id = canvas_colores.create_rectangle((520,10,540,30),fill ='royalblue')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('royalblue'))

id = canvas_colores.create_rectangle((550,10,570,30),fill ='dark red')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('dark red'))

id = canvas_colores.create_rectangle((580,10,600,30),fill ='dark blue')
canvas_colores.tag_bind(id, '<Button-1>', lambda x: mostrar_color('dark blue'))

# botones y scale de control

espesor_pincel = Scale(frame,  orient= HORIZONTAL, from_ = 0, to=50, length=200 ,relief=  'groove', bg='gold', width=17, sliderlength=20, highlightbackground='white',activebackground='red')
espesor_pincel.set(1)
espesor_pincel.grid(column=1, row=0, sticky='ew', pady=1, padx=2)


bt_guardar = Button(frame, text ='Guardar', bg='green2', command = guardar_dibujo, width=10, height=2,activebackground='white', font=('Comic sens MS',10,'bold'), bd=0, highlightthickness=0, relief='flat')
bt_guardar.grid(column=2, row=0, sticky='ew',pady=1,padx=4)

bt_borrar = Button(frame, text ='Borrardor', bg='cyan2', command = borrar, width=10, height=2,activebackground='white',font=('Comic sens MS',10,'bold'), bd=0, highlightthickness=0, relief='flat')
bt_borrar.grid(column=3, row=0, sticky='ew', pady=1, padx=4)


bt_limpiar = Button(frame, text ='Limpiar', bg='violet red', command = limpiar, width=10, height=2,activebackground='white',font=('Comic sens MS',10,'bold'), bd=0, highlightthickness=0, relief='flat')
bt_limpiar.grid(column=4, row=0, sticky='ew', pady=1, padx=4)

bt_salir = Button(frame, text ='Salir', bg='firebrick1', command = salir,  width=10, height=2, activebackground='white',font=('Comic sens MS',10,'bold'), bd=0, highlightthickness=0, relief='flat')
bt_salir.grid(column=5, row=0, sticky='ew',pady=1, padx=4)

bt_stile = Button(frame, text ='Estilo', bg='orange1', command = stile,  width=10, height=2, activebackground='white',font=('Comic sens MS',10,'bold'), bd=0, highlightthickness=0, relief='flat')
bt_stile.grid(column=6, row=0, sticky='ew',pady=1, padx=4)

bt_color = Button(frame, text ='Más Colores', bg='blue1', command = colorch,  width=10, height=2, activebackground='white',font=('Comic sens MS',10,'bold'), bd=0, highlightthickness=0, relief='flat')
bt_color.grid(column=7, row=0, sticky='ew',pady=1, padx=4)

ventana.mainloop()